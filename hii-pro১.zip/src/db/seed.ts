import { db } from "@/db";
import { users, groupSettings, autoReplies, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

let seeded = false;

export async function ensureDbSeeded() {
  if (seeded) return;
  try {
    // 1. Ensure user 99 exists
    const existing99 = await db.select().from(users).where(eq(users.username, "99")).limit(1);
    if (existing99.length === 0) {
      const [u99] = await db.insert(users).values({
        username: "99",
        password: "2390924198",
        isSpecialUser: true,
        displayName: "Admin 99",
        avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf376fde?w=200&h=200&fit=crop",
      }).returning();

      // Default auto-reply for 99
      await db.insert(autoReplies).values({
        userId: u99.id,
        triggerText: "Hi",
        responseText: "hello",
      });
    }

    // 2. Ensure group settings exist with default PIN 2390
    const existingGroup = await db.select().from(groupSettings).limit(1);
    if (existingGroup.length === 0) {
      await db.insert(groupSettings).values({
        pinCode: "2390",
        groupName: "Hii pro VIP Group",
      });
    }

    // 3. Ensure systemSettings exist with default maxUserLimit: 50
    const existingSys = await db.select().from(systemSettings).limit(1);
    if (existingSys.length === 0) {
      await db.insert(systemSettings).values({
        maxUserLimit: 50,
        registrationEnabled: true,
      });
    }

    seeded = true;
  } catch (err) {
    console.error("Seeding error:", err);
  }
}
