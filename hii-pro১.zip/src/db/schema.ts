import { pgTable, serial, varchar, text, boolean, timestamp, integer, pgEnum, doublePrecision } from "drizzle-orm/pg-core";

export const messageTypeEnum = pgEnum("message_type", ["text", "image", "voice", "location"]);
export const locationRequestStatusEnum = pgEnum("location_request_status", ["pending", "approved", "rejected"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 10 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  isSpecialUser: boolean("is_special_user").default(false).notNull(),
  displayName: varchar("display_name", { length: 100 }),
  avatarUrl: text("avatar_url"),
  lastIp: varchar("last_ip", { length: 100 }),
  userAgent: text("user_agent"),
  deviceInfo: varchar("device_info", { length: 255 }),
  lastActiveAt: timestamp("last_active_at").defaultNow().notNull(),
  isOnline: boolean("is_online").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chats = pgTable("chats", {
  id: serial("id").primaryKey(),
  contactNumber: varchar("contact_number", { length: 10 }).notNull(),
  contactName: varchar("contact_name", { length: 100 }),
  lastMessage: text("last_message"),
  lastMessageAt: timestamp("last_message_at").defaultNow().notNull(),
  unreadCount: integer("unread_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  chatId: integer("chat_id").references(() => chats.id).notNull(),
  senderId: integer("sender_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  type: messageTypeEnum("type").default("text").notNull(),
  imageUrl: text("image_url"),
  isPrivateTo99: boolean("is_private_to_99").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  readBySender: boolean("read_by_sender").default(false).notNull(),
  readByReceiver: boolean("read_by_receiver").default(false).notNull(),
});

export const autoReplies = pgTable("auto_replies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  triggerText: varchar("trigger_text", { length: 255 }).notNull(),
  responseText: varchar("response_text", { length: 500 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const groupSettings = pgTable("group_settings", {
  id: serial("id").primaryKey(),
  pinCode: varchar("pin_code", { length: 10 }).notNull().default("2390"),
  groupName: varchar("group_name", { length: 100 }).notNull().default("Hii pro Group"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  maxUserLimit: integer("max_user_limit").notNull().default(50),
  registrationEnabled: boolean("registration_enabled").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const locationRequests = pgTable("location_requests", {
  id: serial("id").primaryKey(),
  requesterId: integer("requester_id").references(() => users.id).notNull(),
  targetUserId: integer("target_user_id").references(() => users.id).notNull(),
  status: locationRequestStatusEnum("status").default("pending").notNull(),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  accuracy: doublePrecision("accuracy"),
  addressText: text("address_text"),
  requestedAt: timestamp("requested_at").defaultNow().notNull(),
  respondedAt: timestamp("responded_at"),
});
