"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

export const dynamic = "force-dynamic";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // Auto-redirect if already logged in (Persistent login / Cookie)
  useEffect(() => {
    let currentUser = null;
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) currentUser = JSON.parse(saved);
    } catch {}

    if (!currentUser) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          currentUser = JSON.parse(decodeURIComponent(match[1]));
        } catch {}
      }
    }

    if (currentUser?.id) {
      router.replace(`/chat-list?userId=${currentUser.id}`);
    }
  }, [router]);

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Strictly numbers only, max 2 digits
    const val = e.target.value.replace(/\D/g, "").slice(0, 2);
    setUsername(val);
    setError("");
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (username.length !== 2) {
      setError("ইউজারনেম শুধুমাত্র যেকোনো ২ সংখ্যার নম্বর দিন (যেমন: 99, 85)");
      return;
    }

    if (!password) {
      setError("দয়া করে পাসওয়ার্ড দিন");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "লগইন ব্যর্থ হয়েছে!");
        setLoading(false);
        return;
      }

      // Save session in localStorage AND document.cookie for permanent mobile login
      const userStr = JSON.stringify(data.user);
      localStorage.setItem("hii_pro_user", userStr);
      document.cookie = `hii_pro_user=${encodeURIComponent(userStr)}; path=/; max-age=315360000; SameSite=Lax`;

      router.push(`/chat-list?userId=${data.user.id}`);
    } catch {
      setError("নেটওয়ার্ক সমস্যা! ইন্টারনেট চেক করে আবার চেষ্টা করুন।");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-between bg-black text-white px-6 py-10 relative overflow-hidden selection:bg-green-500 selection:text-black">
      {/* Glowing Neon Green Effects */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[450px] h-[350px] bg-green-500/20 blur-[130px] pointer-events-none rounded-full" />
      <div className="absolute bottom-0 right-0 w-[350px] h-[300px] bg-green-500/15 blur-[120px] pointer-events-none rounded-full" />

      {/* Main Content Container */}
      <div className="w-full max-w-sm mx-auto flex-1 flex flex-col justify-center items-center relative z-10">
        {/* App Logo & Branding */}
        <div className="flex flex-col items-center mb-8 text-center">
          <div className="relative mb-4">
            {/* Crowned glowing chat bubble logo */}
            <div className="w-28 h-28 rounded-full border-2 border-green-400 bg-black/90 p-1 shadow-[0_0_50px_rgba(0,255,65,0.7)] flex items-center justify-center relative">
              <div className="w-full h-full rounded-full border border-green-500/50 flex flex-col items-center justify-center relative">
                {/* Crown Icon */}
                <span className="text-2xl mb-0.5 filter drop-shadow-[0_0_8px_rgba(255,215,0,0.8)]">👑</span>
                {/* Chat Bubble Icon */}
                <div className="w-11 h-9 bg-white rounded-2xl flex items-center justify-center gap-1 shadow-md">
                  <span className="w-1.5 h-1.5 bg-black rounded-full" />
                  <span className="w-1.5 h-1.5 bg-black rounded-full" />
                  <span className="w-1.5 h-1.5 bg-black rounded-full" />
                </div>
              </div>
            </div>
          </div>

          <h1 className="text-4xl font-extrabold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-green-300 via-green-400 to-green-500 drop-shadow-[0_0_20px_rgba(0,255,65,0.8)]">
            Hii pro
          </h1>
          <p className="text-green-400 text-xs font-semibold tracking-widest mt-1 uppercase">
            Chat • Connect • Earn
          </p>
        </div>

        {/* Login Form Card */}
        <form onSubmit={handleLogin} className="w-full space-y-4">
          {/* Input 1: 2-Digit Username */}
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-green-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </div>
            <input
              type="tel"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={2}
              value={username}
              onChange={handleUsernameChange}
              placeholder="Enter Number"
              className="w-full bg-black/60 border border-green-500/50 rounded-full pl-12 pr-4 py-3.5 text-green-300 placeholder-green-600/70 text-base font-mono focus:outline-none focus:border-green-400 focus:shadow-[0_0_25px_rgba(0,255,65,0.4)] transition-all"
              autoComplete="username"
            />
          </div>

          {/* Input 2: Secret Password */}
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-green-400">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
              placeholder="Enter Password"
              className="w-full bg-black/60 border border-green-500/50 rounded-full pl-12 pr-4 py-3.5 text-green-300 placeholder-green-600/70 text-base font-mono focus:outline-none focus:border-green-400 focus:shadow-[0_0_25px_rgba(0,255,65,0.4)] transition-all"
              autoComplete="current-password"
            />
          </div>

          {/* Error Message Display */}
          {error && (
            <div className="bg-red-950/80 border border-red-500/50 rounded-xl px-4 py-2 text-red-300 text-xs text-center shadow-[0_0_15px_rgba(239,68,68,0.3)]">
              {error}
            </div>
          )}

          {/* Glowing Green Login Button */}
          <button
            type="submit"
            disabled={loading || username.length !== 2 || !password}
            className={`w-full py-3.5 rounded-full font-bold text-black text-base tracking-wide transition-all duration-300 flex items-center justify-center gap-2 ${
              loading || username.length !== 2 || !password
                ? "bg-green-500/30 text-green-700 cursor-not-allowed border border-green-500/30"
                : "bg-gradient-to-r from-green-400 via-green-500 to-green-400 shadow-[0_0_35px_rgba(0,255,65,0.7)] hover:shadow-[0_0_45px_rgba(0,255,65,0.9)] hover:scale-[1.02] active:scale-[0.98]"
            }`}
          >
            {loading ? (
              <span>Logging in...</span>
            ) : (
              <>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                </svg>
                <span>Login</span>
              </>
            )}
          </button>
        </form>

        {/* Info Text */}
        <p className="mt-4 text-[11px] text-green-500/50 text-center">
          ২ অঙ্কের নম্বর দিয়ে পাসওয়ার্ড দিয়ে লগইন করুন
        </p>
      </div>

      {/* Footer Branding - Always with you */}
      <footer className="w-full text-center py-2 relative z-10">
        <p className="text-green-400/80 text-xs font-medium tracking-wide">
          Hii pro — Always with you 💚
        </p>
      </footer>
    </div>
  );
}
