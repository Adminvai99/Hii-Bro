"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { LocationRequestModal } from "@/components/LocationRequestModal";

export const dynamic = "force-dynamic";

interface MessageItem {
  id: number;
  chatId: number;
  senderId: number;
  content: string;
  type: string;
  imageUrl: string | null;
  createdAt: string;
  readBySender: boolean;
  readByReceiver: boolean;
  senderUsername: string;
  senderIsSpecial: boolean;
  senderAvatar?: string | null;
}

interface AutoReplyItem {
  id: number;
  triggerText: string;
  responseText: string;
}

interface TargetUserDetails {
  id: number;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  isOnline: boolean;
  lastActiveAt: string;
}

export default function ChatRoomPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pathname = usePathname();

  const contact = (pathname.split("/").pop() as string) || "85";
  const userId = searchParams.get("userId") || "1";

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [targetUser, setTargetUser] = useState<TargetUserDetails | null>(null);
  const [messages, setMessages] = useState<MessageItem[]>([]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [verifyingPhoto, setVerifyingPhoto] = useState(false);
  const [alertNotice, setAlertNotice] = useState<string | null>(null);
  const [locationSentSuccess, setLocationSentSuccess] = useState<string | null>(null);

  // User 99 Special Auto-Reply & Group PIN states
  const [showSpecialPanel, setShowSpecialPanel] = useState(false);
  const [triggerInput, setTriggerInput] = useState("");
  const [responseInput, setResponseInput] = useState("");
  const [autoRepliesList, setAutoRepliesList] = useState<AutoReplyItem[]>([]);
  const [groupPinInput, setGroupPinInput] = useState("");
  const [pinStatusMsg, setPinStatusMsg] = useState("");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load session
  useEffect(() => {
    let user = null;
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) user = JSON.parse(saved);
    } catch {}

    if (!user) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          user = JSON.parse(decodeURIComponent(match[1]));
        } catch {}
      }
    }

    if (user?.id) {
      setCurrentUser(user);
    } else {
      router.replace("/login");
    }
  }, [router]);

  const is99 = currentUser?.username === "99" || currentUser?.isSpecialUser;
  const isChattingWith99 = contact === "99";

  // Real-time Heartbeat
  useEffect(() => {
    if (!currentUser?.id) return;
    const sendHeartbeat = async (online: boolean) => {
      try {
        await fetch("/api/user/heartbeat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: currentUser.id, isOnline: online }),
        });
      } catch {}
    };

    sendHeartbeat(true);
    const interval = setInterval(() => sendHeartbeat(true), 20000);
    return () => clearInterval(interval);
  }, [currentUser]);

  // Fetch messages and real-time online status of target contact
  const loadMessages = useCallback(async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/messages?contact=${contact}&userId=${currentUser.id}`);
      const data = await res.json();
      if (data.messages) {
        setMessages(data.messages);
      }
      if (data.targetUser) {
        setTargetUser(data.targetUser);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [contact, currentUser]);

  // Fetch Auto Replies & current PIN for user 99
  const loadSpecialData = useCallback(async () => {
    if (!is99 || !currentUser) return;
    try {
      const repRes = await fetch(`/api/auto-replies?userId=${currentUser.id}`);
      const repData = await repRes.json();
      if (repData.autoReplies) setAutoRepliesList(repData.autoReplies);

      const pinRes = await fetch(`/api/group-pin?userId=${currentUser.id}`);
      const pinData = await pinRes.json();
      if (pinData.pinCode) setGroupPinInput(pinData.pinCode);
    } catch (e) {
      console.error(e);
    }
  }, [is99, currentUser]);

  useEffect(() => {
    if (currentUser) {
      loadMessages();
      if (is99) {
        loadSpecialData();
      }
      // Poll every 5s for new messages and real-time active/offline status
      const interval = setInterval(loadMessages, 5000);
      return () => clearInterval(interval);
    }
  }, [currentUser, loadMessages, is99, loadSpecialData]);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Send message
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || sending) return;

    const textToSend = inputText.trim();
    setInputText("");
    setSending(true);

    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contact,
          senderId: currentUser.id,
          content: textToSend,
          type: "text",
        }),
      });

      if (res.ok) {
        await loadMessages();
      }
    } catch (err) {
      console.error(err);
      alert("মেসেজ পাঠানো যায়নি");
    } finally {
      setSending(false);
    }
  };

  // Image Upload with Real-time Human/Person Detection
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      if (!base64) return;

      if (isChattingWith99 && !is99) {
        setVerifyingPhoto(true);
        setAlertNotice("ছবিটি মানুষের কি না তা যাচাই করা হচ্ছে...");

        try {
          const checkRes = await fetch("/api/verify-photo", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ imageBase64: base64 }),
          });

          const checkData = await checkRes.json();

          if (!checkData.isPerson) {
            setVerifyingPhoto(false);
            setAlertNotice(
              checkData.reason ||
                "এটি কোনো ব্যক্তির ছবি নয়! ৯৯ এর কাছে পাঠানোর জন্য মানুষের আসল মুখমণ্ডল/সেলফি ছবি প্রদান করুন।"
            );
            return;
          }
        } catch {
          setVerifyingPhoto(false);
          setAlertNotice("ছবি যাচাই করা যায়নি। দয়া করে আবার চেষ্টা করুন।");
          return;
        }
      }

      setAlertNotice(null);
      setVerifyingPhoto(false);

      try {
        const sendRes = await fetch("/api/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contact,
            senderId: currentUser.id,
            content: "📷 Photo",
            type: "image",
            imageUrl: base64,
          }),
        });

        const sendData = await sendRes.json();

        if (!sendRes.ok) {
          setAlertNotice(sendData.error || "ছবি পাঠাতে ব্যর্থ হয়েছে।");
        } else {
          loadMessages();
        }
      } catch (err) {
        console.error(err);
        alert("ছবি পাঠানো যায়নি");
      }
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  // Requirement 3: 99 sends Location Request to this user
  const handleSendLocationRequest = async () => {
    if (!targetUser?.id) {
      alert("ইউজার পাওয়া যায়নি");
      return;
    }

    try {
      const res = await fetch("/api/location-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminId: currentUser.id,
          targetUserId: targetUser.id,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setLocationSentSuccess("ইউজারের মোবাইলে সফলভাবে লোকেশন রিকোয়েস্ট পপআপ পাঠানো হয়েছে!");
        setTimeout(() => setLocationSentSuccess(null), 4000);
      } else {
        alert(data.error || "লোকেশন রিকোয়েস্ট পাঠানো যায়নি");
      }
    } catch {
      alert("সমস্যা হয়েছে");
    }
  };

  // User 99 edit other messages
  const handleEditOtherMessage = async (msgId: number, currentContent: string) => {
    if (!is99) return;
    const newText = window.prompt("মেসেজটি এডিট করুন:", currentContent);
    if (newText === null || newText.trim() === "") return;

    try {
      const res = await fetch("/api/messages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messageId: msgId,
          content: newText.trim(),
          userId: currentUser.id,
        }),
      });
      if (res.ok) {
        loadMessages();
      } else {
        alert("মেসেজ এডিট করতে ব্যর্থ হয়েছে");
      }
    } catch {
      alert("এডিট ব্যর্থ হয়েছে");
    }
  };

  // User 99 Save Auto-Reply
  const handleSaveAutoReply = async () => {
    if (!triggerInput.trim() || !responseInput.trim()) return;

    try {
      const res = await fetch("/api/auto-replies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          triggerText: triggerInput.trim(),
          responseText: responseInput.trim(),
        }),
      });

      if (res.ok) {
        setTriggerInput("");
        setResponseInput("");
        loadSpecialData();
      } else {
        alert("অটো-মেসেজ সেভ করা যায়নি");
      }
    } catch {
      alert("সমস্যা হয়েছে");
    }
  };

  const handleDeleteAutoReply = async (id: number) => {
    try {
      await fetch(`/api/auto-replies?id=${id}&userId=${currentUser.id}`, { method: "DELETE" });
      loadSpecialData();
    } catch {}
  };

  const handleUpdateGroupPin = async () => {
    if (!groupPinInput.trim()) return;
    try {
      const res = await fetch("/api/group-pin", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          newPin: groupPinInput.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setPinStatusMsg("গ্রুপ পিন সফলভাবে পরিবর্তন হয়েছে!");
        setTimeout(() => setPinStatusMsg(""), 3000);
      } else {
        alert(data.error || "পিন পরিবর্তন ব্যর্থ হয়েছে");
      }
    } catch {
      alert("সমস্যা হয়েছে");
    }
  };

  if (!currentUser) {
    return <div className="min-h-screen bg-black" />;
  }

  const canShowSaveBtn = triggerInput.trim().length > 0 && responseInput.trim().length > 0;
  const isTargetOnline = targetUser ? targetUser.isOnline : false;

  return (
    <div className="min-h-screen bg-black text-white flex flex-col relative overflow-hidden select-none">
      {/* Location Request Modal for regular user */}
      <LocationRequestModal currentUserId={currentUser.id} />

      {/* Background neon ambient */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-green-500/10 blur-[110px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-green-500/10 blur-[110px] pointer-events-none" />

      {/* Header - Strictly NO phone status bar (no wifi/time/battery) */}
      <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-green-500/20 px-3 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {/* Back button */}
          <button
            onClick={() => router.push(`/chat-list?userId=${currentUser.id}`)}
            className="p-1.5 rounded-full hover:bg-green-500/20 text-green-400 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          {/* Contact 2-digit Glowing Avatar Circle */}
          <div
            className={`w-10 h-10 rounded-full border-2 flex items-center justify-center text-sm font-bold font-mono ${
              contact === "99"
                ? "border-yellow-400 text-yellow-300 bg-yellow-950/40 shadow-[0_0_15px_rgba(255,215,0,0.5)]"
                : "border-green-400 text-green-300 bg-black shadow-[0_0_15px_rgba(0,255,65,0.4)]"
            }`}
          >
            {contact}
          </div>

          {/* Contact Name & Real-time Active/Offline Status */}
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm font-bold text-white tracking-wide">{contact}</h2>
              {contact === "99" && (
                <span className="text-[9px] bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 px-1 rounded-full">
                  Admin
                </span>
              )}
            </div>

            {/* REAL-TIME ONLINE / OFFLINE INDICATOR */}
            <div className="flex items-center gap-1.5 mt-0.5">
              {isTargetOnline ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_8px_#00ff41]" />
                  <span className="text-[11px] text-green-400 font-bold">অ্যাক্টিভ (Online)</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-red-500/80" />
                  <span className="text-[11px] text-red-400/90 font-medium">অফলাইন (Offline)</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Right side: 99 Admin & Location Request Button + 3-dot Menu (NO call buttons) */}
        <div className="flex items-center gap-1.5">
          {is99 && (
            <>
              {/* Location Request Button (Requirement 3) */}
              {!isChattingWith99 && (
                <button
                  onClick={handleSendLocationRequest}
                  className="px-2 py-1 rounded-full bg-blue-500/20 border border-blue-400 text-blue-300 text-[11px] font-bold hover:bg-blue-500/30 flex items-center gap-1 shadow-[0_0_12px_rgba(59,130,246,0.4)] transition-all"
                  title="ইউজারকে লাইভ লোকেশন রিকোয়েস্ট পাঠান"
                >
                  <span>📍 লোকেশন</span>
                </button>
              )}

              <button
                onClick={() => router.push(`/admin?userId=${currentUser.id}`)}
                className="px-2 py-1 rounded-full bg-yellow-500/20 border border-yellow-400 text-yellow-300 text-[11px] font-bold hover:bg-yellow-500/30 flex items-center gap-1 shadow-[0_0_12px_rgba(255,215,0,0.3)] transition-all"
                title="Open Admin Panel"
              >
                <span>👑 এডমিন</span>
              </button>

              <button
                onClick={() => setShowSpecialPanel(!showSpecialPanel)}
                className="px-2 py-1 rounded-full bg-green-500/20 border border-green-400/80 text-green-300 text-[11px] font-bold hover:bg-green-500/30 flex items-center gap-1 shadow-[0_0_12px_rgba(0,255,65,0.3)] transition-all"
              >
                <span>⚙️ পাওয়ার</span>
              </button>
            </>
          )}

          <button className="p-1.5 text-green-400 hover:text-green-300 rounded-full hover:bg-green-500/10">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
            </svg>
          </button>
        </div>
      </header>

      {/* Location request sent toast message */}
      {locationSentSuccess && (
        <div className="bg-blue-950/90 border-b border-blue-500/60 px-4 py-2 text-xs text-blue-200 text-center font-bold animate-in fade-in z-20">
          ✓ {locationSentSuccess}
        </div>
      )}

      {/* Warning/Verification Notice Banner when sending photo */}
      {alertNotice && (
        <div className="bg-red-950/90 border-b border-red-500/60 px-4 py-2.5 text-xs text-red-200 flex items-center justify-between z-20 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="text-base">⚠️</span>
            <span>{alertNotice}</span>
          </div>
          <button
            onClick={() => setAlertNotice(null)}
            className="text-red-400 hover:text-white font-bold text-sm ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* User 99 Special Control Panel */}
      {is99 && showSpecialPanel && (
        <div className="bg-black/95 border-b border-green-500/40 p-4 relative z-20 shadow-[0_10px_30px_rgba(0,255,65,0.2)] animate-in fade-in slide-in-from-top duration-200">
          <div className="max-w-md mx-auto space-y-4">
            <div className="flex items-center justify-between border-b border-green-500/20 pb-2">
              <span className="text-xs font-bold text-green-400 uppercase tracking-wider">
                ⚡ 99 অটো-মেসেজ ও গ্রুপ পিন সেটিংস
              </span>
              <button
                onClick={() => setShowSpecialPanel(false)}
                className="text-xs text-green-500/60 hover:text-green-400"
              >
                ✕ বন্ধ করুন
              </button>
            </div>

            <div className="space-y-2">
              <p className="text-[11px] text-green-300 font-medium">অটো-মেসেজ সেট করুন (যেমন: Hi দিলে hello যাবে):</p>
              <div>
                <label className="text-[10px] text-green-500/70 block mb-1">
                  বক্স ১: ইনকামিং মেসেজ (Trigger, যেমন: Hi)
                </label>
                <input
                  type="text"
                  value={triggerInput}
                  onChange={(e) => setTriggerInput(e.target.value)}
                  placeholder="যেমন: Hi"
                  className="w-full bg-green-950/30 border border-green-500/40 rounded-xl px-3 py-2 text-xs text-green-300 placeholder-green-700 focus:outline-none focus:border-green-400"
                />
              </div>

              <div>
                <label className="text-[10px] text-green-500/70 block mb-1">
                  বক্স ২: উত্তরের মেসেজ (Answer, যেমন: hello)
                </label>
                <input
                  type="text"
                  value={responseInput}
                  onChange={(e) => setResponseInput(e.target.value)}
                  placeholder="যেমন: hello"
                  className="w-full bg-green-950/30 border border-green-500/40 rounded-xl px-3 py-2 text-xs text-green-300 placeholder-green-700 focus:outline-none focus:border-green-400"
                />
              </div>

              {canShowSaveBtn && (
                <button
                  onClick={handleSaveAutoReply}
                  className="w-full py-2 rounded-xl bg-gradient-to-r from-green-400 to-green-500 text-black text-xs font-bold shadow-[0_0_20px_rgba(0,255,65,0.5)] hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-1.5"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>সেভ করুন (Save Auto Reply)</span>
                </button>
              )}

              {autoRepliesList.length > 0 && (
                <div className="pt-2">
                  <span className="text-[10px] text-green-500/70 block mb-1">সেভ করা অটো-মেসেজ সমূহ:</span>
                  <div className="space-y-1 max-h-24 overflow-y-auto">
                    {autoRepliesList.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between bg-black/60 border border-green-500/20 px-2.5 py-1 rounded-lg text-xs"
                      >
                        <span className="text-green-300">
                          <span className="text-green-400 font-bold">"{item.triggerText}"</span> ➔ "{item.responseText}"
                        </span>
                        <button
                          onClick={() => handleDeleteAutoReply(item.id)}
                          className="text-red-400 hover:text-red-300 text-[10px] ml-2"
                        >
                          মুছুন
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="border-t border-green-500/20 pt-3 space-y-2">
              <label className="text-[11px] text-green-300 font-medium block">
                🔐 গ্রুপের পিন কোড এডিট করুন (Change Group PIN):
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  maxLength={6}
                  value={groupPinInput}
                  onChange={(e) => setGroupPinInput(e.target.value.replace(/\D/g, ""))}
                  placeholder="নতুন পিন"
                  className="flex-1 bg-green-950/30 border border-green-500/40 rounded-xl px-3 py-1.5 text-xs text-green-300 focus:outline-none focus:border-green-400 font-mono"
                />
                <button
                  onClick={handleUpdateGroupPin}
                  className="px-4 py-1.5 rounded-xl bg-green-500 text-black text-xs font-bold hover:bg-green-400 shadow-[0_0_15px_rgba(0,255,65,0.4)]"
                >
                  আপডেট
                </button>
              </div>
              {pinStatusMsg && (
                <p className="text-[10px] text-green-400 font-medium">{pinStatusMsg}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Messages Scrollable Area */}
      <main className="flex-1 overflow-y-auto px-4 py-3 space-y-3 relative z-10">
        {loading ? (
          <div className="py-20 text-center text-green-500/50 text-xs">মেসেজ লোড হচ্ছে...</div>
        ) : messages.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-green-500/60 text-xs">কোনো মেসেজ নেই। নিচে টাইপ করে পাঠান।</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.senderId === currentUser.id;
            const canEdit = is99 && !isMe;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? "items-end" : "items-start"}`}
              >
                <div className="group relative max-w-[82%]">
                  {/* Image Type Message */}
                  {msg.type === "image" && msg.imageUrl ? (
                    <div
                      className={`rounded-2xl p-1.5 border ${
                        isMe
                          ? "border-green-400 bg-green-950/40 shadow-[0_0_20px_rgba(0,255,65,0.3)]"
                          : "border-green-500/40 bg-black shadow-[0_0_15px_rgba(0,255,65,0.15)]"
                      }`}
                    >
                      <img
                        src={msg.imageUrl}
                        alt="Photo"
                        className="rounded-xl max-h-72 w-full object-cover cursor-pointer hover:opacity-95 transition-opacity"
                        onClick={() => window.open(msg.imageUrl!, "_blank")}
                      />
                      <div className="flex items-center justify-end gap-1 px-1 pt-1">
                        <span className="text-[10px] text-green-400/80 font-mono">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </span>
                        {isMe && <span className="text-green-400 text-[10px]">✓✓</span>}
                      </div>
                    </div>
                  ) : (
                    /* Text / Voice Type Message */
                    <div
                      className={`rounded-2xl px-3.5 py-2 text-xs transition-all ${
                        isMe
                          ? "bg-green-500 text-black font-semibold shadow-[0_0_15px_rgba(0,255,65,0.3)] rounded-br-xs"
                          : "bg-black/80 border border-green-500/40 text-green-200 rounded-bl-xs shadow-[0_0_12px_rgba(0,255,65,0.1)]"
                      }`}
                    >
                      <p className="break-words leading-relaxed whitespace-pre-wrap">{msg.content}</p>

                      <div
                        className={`flex items-center justify-end gap-1 mt-1 text-[9px] font-mono ${
                          isMe ? "text-black/70" : "text-green-500/70"
                        }`}
                      >
                        <span>
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </span>
                        {isMe && <span>✓✓</span>}
                      </div>
                    </div>
                  )}

                  {/* 99 User Edit Button */}
                  {canEdit && (
                    <button
                      onClick={() => handleEditOtherMessage(msg.id, msg.content)}
                      className="opacity-80 hover:opacity-100 text-[9px] text-yellow-400 bg-black/80 border border-yellow-500/40 rounded px-1.5 py-0.5 mt-0.5 flex items-center gap-1 shadow"
                    >
                      <span>✏️ এডিট</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </main>

      {/* Compact & Mobile-Friendly Input Bar */}
      <footer className="sticky bottom-0 z-30 bg-black/95 backdrop-blur-xl border-t border-green-500/30 px-2.5 py-1.5 safe-bottom">
        <form onSubmit={handleSendMessage} className="max-w-md mx-auto flex items-center gap-1.5">
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />

          {/* Emoji button (Compact 32px) */}
          <button
            type="button"
            onClick={() => setInputText((prev) => prev + "😊")}
            className="w-8 h-8 flex items-center justify-center text-green-400 hover:text-green-300 rounded-full hover:bg-green-500/20 transition-colors shrink-0"
            title="Emoji"
          >
            <span className="text-lg">😊</span>
          </button>

          {/* Photo Gallery Button (Compact 32px) */}
          <button
            type="button"
            disabled={verifyingPhoto}
            onClick={() => fileInputRef.current?.click()}
            className="w-8 h-8 flex items-center justify-center rounded-full border border-green-500/50 text-green-400 hover:bg-green-500/20 shadow-[0_0_10px_rgba(0,255,65,0.2)] transition-all shrink-0"
            title="Upload photo"
          >
            {verifyingPhoto ? (
              <span className="w-3.5 h-3.5 border-2 border-green-400 border-t-transparent rounded-full animate-spin block" />
            ) : (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            )}
          </button>

          {/* Text Input Box (Compact Height) */}
          <div className="flex-1 min-w-0">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type message..."
              className="w-full bg-black/70 border border-green-500/40 rounded-full px-3.5 py-1.5 text-xs text-green-300 placeholder-green-600/70 focus:outline-none focus:border-green-400 focus:shadow-[0_0_15px_rgba(0,255,65,0.3)] transition-all"
            />
          </div>

          {/* Glowing Green Send Button (Compact 32px) */}
          <button
            type="submit"
            disabled={!inputText.trim() || sending}
            className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all ${
              !inputText.trim() || sending
                ? "bg-green-950/40 text-green-700 border border-green-500/20 cursor-not-allowed"
                : "bg-gradient-to-r from-green-400 to-green-500 text-black shadow-[0_0_15px_rgba(0,255,65,0.7)] hover:scale-105 active:scale-95"
            }`}
          >
            <svg className="w-4 h-4 rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19V5m0 0l-7 7m7-7l7 7" />
            </svg>
          </button>
        </form>
      </footer>
    </div>
  );
}
