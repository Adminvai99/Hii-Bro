import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hii pro - Chat • Connect • Earn",
  description: "Neon green chat application",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-black text-green-300 antialiased selection:bg-green-500 selection:text-black">{children}</body>
    </html>
  );
}
