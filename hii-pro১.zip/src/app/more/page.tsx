"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export const dynamic = "force-dynamic";

export default function MorePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [avatarPreview, setAvatarPreview] = useState<string>("");
  const [displayName, setDisplayName] = useState<string>("");
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  // Load session
  useEffect(() => {
    let user = null;
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) user = JSON.parse(saved);
    } catch {}

    if (!user) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          user = JSON.parse(decodeURIComponent(match[1]));
        } catch {}
      }
    }

    if (user?.id) {
      setCurrentUser(user);
      setAvatarPreview(user.avatarUrl || "");
      setDisplayName(user.displayName || `User ${user.username}`);
    } else {
      router.replace("/login");
    }
  }, [router]);

  // Profile image upload
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        setAvatarPreview(base64);
      }
    };
    reader.readAsDataURL(file);
  };

  // Save profile changes
  const handleSaveProfile = async () => {
    if (!currentUser) return;
    setSaving(true);
    setSuccessMsg("");

    try {
      const res = await fetch("/api/user/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          avatarUrl: avatarPreview,
          displayName: displayName.trim(),
        }),
      });

      const data = await res.json();
      if (res.ok && data.user) {
        setCurrentUser(data.user);
        const str = JSON.stringify(data.user);
        localStorage.setItem("hii_pro_user", str);
        document.cookie = `hii_pro_user=${encodeURIComponent(str)}; path=/; max-age=315360000; SameSite=Lax`;
        setSuccessMsg("প্রোফাইল ছবি সফলভাবে আপডেট হয়েছে! 🎉");
        setTimeout(() => setSuccessMsg(""), 3000);
      } else {
        alert(data.error || "আপডেট ব্যর্থ হয়েছে");
      }
    } catch {
      alert("সমস্যা হয়েছে");
    } finally {
      setSaving(false);
    }
  };

  // Logout
  const handleLogout = () => {
    if (confirm("আপনি কি নিশ্চিত লগআউট করতে চান?")) {
      localStorage.removeItem("hii_pro_user");
      document.cookie = "hii_pro_user=; path=/; max-age=0";
      router.replace("/login");
    }
  };

  if (!currentUser) {
    return <div className="min-h-screen bg-black" />;
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col justify-between relative overflow-hidden select-none">
      <div className="absolute top-0 right-0 w-80 h-80 bg-green-500/10 blur-[110px] pointer-events-none" />

      {/* Header - strictly NO phone status bar */}
      <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-green-500/20 px-4 py-3 flex items-center justify-between">
        <button
          onClick={() => router.push(`/chat-list?userId=${currentUser.id}`)}
          className="flex items-center gap-1.5 text-green-400 text-sm font-semibold"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
          </svg>
          <span>Back</span>
        </button>
        <h1 className="text-base font-bold text-green-400">Profile & Settings</h1>
        <div className="w-8" />
      </header>

      {/* Profile Section */}
      <main className="flex-1 overflow-y-auto px-5 py-6 space-y-6 pb-24 relative z-10">
        {/* User Card with Profile Picture Upload */}
        <div className="bg-black/80 border border-green-500/40 rounded-3xl p-6 text-center shadow-[0_0_35px_rgba(0,255,65,0.15)]">
          {/* Avatar with Camera Overlay */}
          <div className="relative w-24 h-24 mx-auto mb-4 group">
            <div className="w-24 h-24 rounded-full border-2 border-green-400 bg-green-950/40 overflow-hidden flex items-center justify-center text-3xl font-bold font-mono text-green-300 shadow-[0_0_25px_rgba(0,255,65,0.4)]">
              {avatarPreview ? (
                <img src={avatarPreview} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <span>{currentUser.username}</span>
              )}
            </div>

            {/* Hidden file input */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handlePhotoSelect}
              className="hidden"
            />

            {/* Tap to change badge */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-green-500 text-black flex items-center justify-center shadow-[0_0_15px_rgba(0,255,65,0.7)] hover:scale-110 active:scale-95 transition-all"
              title="Change Photo"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="text-xs text-green-400 hover:text-green-300 font-semibold underline mb-4 block mx-auto"
          >
            📸 প্রোফাইল ছবি পরিবর্তন করুন (Change Photo)
          </button>

          <h2 className="text-xl font-extrabold text-white">
            User {currentUser.username}
          </h2>
          <p className="text-xs text-green-400 font-mono mt-0.5">
            Username Number: {currentUser.username}
          </p>

          {/* Name edit */}
          <div className="mt-5 space-y-3 text-left">
            <div>
              <label className="text-[11px] text-green-400/80 block mb-1">ডিসপ্লে নাম (Display Name):</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-black/60 border border-green-500/40 rounded-xl px-3.5 py-2 text-xs text-green-300 focus:outline-none focus:border-green-400 font-medium"
              />
            </div>

            {successMsg && (
              <p className="text-xs text-green-400 text-center font-bold bg-green-950/40 border border-green-500/30 rounded-xl py-1.5">
                {successMsg}
              </p>
            )}

            <button
              onClick={handleSaveProfile}
              disabled={saving}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-green-400 to-green-500 text-black text-xs font-bold shadow-[0_0_20px_rgba(0,255,65,0.5)] hover:scale-[1.01] active:scale-[0.99] transition-all"
            >
              {saving ? "সংরক্ষণ করা হচ্ছে..." : "প্রোফাইল সেভ করুন"}
            </button>
          </div>
        </div>

        {/* 99 Admin Panel Shortcut */}
        {currentUser.isSpecialUser && (
          <div
            onClick={() => router.push(`/admin?userId=${currentUser.id}`)}
            className="bg-yellow-950/20 border border-yellow-500/40 rounded-2xl p-4 flex items-center justify-between cursor-pointer hover:bg-yellow-950/40 shadow-[0_0_20px_rgba(255,215,0,0.15)] transition-all"
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">👑</span>
              <div>
                <h3 className="text-white font-bold text-sm">Admin 99 কন্ট্রোল প্যানেল</h3>
                <p className="text-[11px] text-yellow-300/80">ইউজারদের মেসেজ, ছবি, মোবাইল মডেল ও লিমিট নিয়ন্ত্রণ করুন</p>
              </div>
            </div>
            <span className="text-yellow-400 font-bold text-sm">➔</span>
          </div>
        )}

        {/* Other Options */}
        <div className="bg-black/60 border border-green-500/30 rounded-2xl overflow-hidden divide-y divide-green-500/20 text-sm">
          <div className="flex items-center justify-between p-4 hover:bg-green-500/10 transition-colors cursor-pointer">
            <div className="flex items-center gap-3 text-green-300">
              <span className="text-lg">🔔</span>
              <span>Notifications</span>
            </div>
            <span className="text-xs text-green-400">On</span>
          </div>

          <div className="flex items-center justify-between p-4 hover:bg-green-500/10 transition-colors cursor-pointer">
            <div className="flex items-center gap-3 text-green-300">
              <span className="text-lg">🛡️</span>
              <span>Privacy & Security</span>
            </div>
            <span className="text-xs text-green-500/60">Active</span>
          </div>

          <div className="flex items-center justify-between p-4 hover:bg-green-500/10 transition-colors cursor-pointer">
            <div className="flex items-center gap-3 text-green-300">
              <span className="text-lg">💬</span>
              <span>Chat Theme</span>
            </div>
            <span className="text-xs text-green-400">Neon Green & Black</span>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          className="w-full py-3 rounded-2xl border border-red-500/50 bg-red-950/30 text-red-400 text-xs font-bold hover:bg-red-900/40 transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
          <span>লগআউট করুন (Logout)</span>
        </button>
      </main>

      {/* Bottom Nav */}
      <BottomNav active="more" userId={currentUser.id} />
    </div>
  );
}

function BottomNav({ active, userId }: { active: string; userId: number }) {
  const router = useRouter();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-black/90 backdrop-blur-xl border-t border-green-500/30 px-6 py-2.5">
      <div className="max-w-md mx-auto flex items-center justify-around">
        <button
          onClick={() => router.push(`/chat-list?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "chats" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          <span className="text-[11px] font-medium">Chats</span>
        </button>

        <button
          onClick={() => router.push(`/group?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "group" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.127-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.127-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <span className="text-[11px] font-medium">Group</span>
        </button>

        <button
          onClick={() => router.push(`/invite?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "invite" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
          </svg>
          <span className="text-[11px] font-medium">Invite</span>
        </button>

        <button
          className={`flex flex-col items-center gap-1 ${
            active === "more" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <div className="p-1 rounded-full bg-green-500/20 shadow-[0_0_12px_rgba(0,255,65,0.5)]">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </div>
          <span className="text-[11px] font-semibold">More</span>
        </button>
      </div>
    </nav>
  );
}
