export default function Loading() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-green-400 animate-pulse font-mono text-sm">Admin Panel লোড হচ্ছে...</div>
    </div>
  );
}
