"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export const dynamic = "force-dynamic";

interface AdminUser {
  id: number;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  deviceInfo: string | null;
  lastIp: string | null;
  isSpecialUser: boolean;
  lastActiveAt: string;
  createdAt: string;
}

interface AdminMessage {
  id: number;
  chatId: number;
  content: string;
  type: string;
  imageUrl: string | null;
  isPrivateTo99: boolean;
  createdAt: string;
  senderId: number;
  senderUsername: string;
  senderDevice: string | null;
  senderIp: string | null;
  contactNumber: string;
}

interface LocationReqRecord {
  id: number;
  requesterId: number;
  targetUserId: number;
  targetUsername: string;
  targetDisplayName: string | null;
  targetAvatar: string | null;
  targetDevice: string | null;
  targetIp: string | null;
  status: "pending" | "approved" | "rejected";
  latitude: number | null;
  longitude: number | null;
  accuracy: number | null;
  addressText: string | null;
  requestedAt: string;
  respondedAt: string | null;
}

export default function AdminPanelPage() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"users" | "messages" | "locations" | "settings">("users");

  const [usersList, setUsersList] = useState<AdminUser[]>([]);
  const [messagesList, setMessagesList] = useState<AdminMessage[]>([]);
  const [locationRequests, setLocationRequests] = useState<LocationReqRecord[]>([]);
  const [stats, setStats] = useState({ totalUsers: 0, totalMessages: 0, groupPin: "2390" });
  const [maxLimitInput, setMaxLimitInput] = useState<number>(50);
  const [regEnabled, setRegEnabled] = useState<boolean>(true);
  const [saveStatus, setSaveStatus] = useState<string>("");
  const [reqActionMsg, setReqActionMsg] = useState<string>("");

  // Load session & verify 99
  useEffect(() => {
    let user = null;
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) user = JSON.parse(saved);
    } catch {}

    if (!user) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          user = JSON.parse(decodeURIComponent(match[1]));
        } catch {}
      }
    }

    if (!user || (user.username !== "99" && !user.isSpecialUser)) {
      alert("অননুমোদিত অ্যাক্সেস! শুধুমাত্র ৯৯ এই এডমিন প্যানেলে ঢুকতে পারবে।");
      router.replace("/chat-list");
      return;
    }

    setCurrentUser(user);
  }, [router]);

  // Fetch admin overview data
  const fetchAdminData = useCallback(async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/admin/overview?userId=${currentUser.id}`);
      const data = await res.json();

      if (data.success) {
        setUsersList(data.users || []);
        setMessagesList(data.messages || []);
        setStats(data.stats || { totalUsers: 0, totalMessages: 0, groupPin: "2390" });
        setMaxLimitInput(data.systemSettings?.maxUserLimit ?? 50);
        setRegEnabled(data.systemSettings?.registrationEnabled ?? true);
      }

      // Fetch location requests
      const locRes = await fetch(`/api/location-request?userId=${currentUser.id}`);
      const locData = await locRes.json();
      if (locData.success) {
        setLocationRequests(locData.requests || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    if (currentUser) {
      fetchAdminData();
      const interval = setInterval(fetchAdminData, 8000);
      return () => clearInterval(interval);
    }
  }, [currentUser, fetchAdminData]);

  // Save Limit & Registration status
  const handleSaveSettings = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/admin/overview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          maxUserLimit: maxLimitInput,
          registrationEnabled: regEnabled,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSaveStatus(data.message);
        setTimeout(() => setSaveStatus(""), 4000);
        fetchAdminData();
      } else {
        alert(data.error || "সেভ ব্যর্থ হয়েছে");
      }
    } catch {
      alert("সমস্যা হয়েছে");
    }
  };

  // Send Location Request directly from Admin Panel to a specific user
  const handleSendLocationReqToUser = async (targetUserId: number, targetUsername: string) => {
    try {
      const res = await fetch("/api/location-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminId: currentUser.id,
          targetUserId,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setReqActionMsg(`ইউজার ${targetUsername}-এর মোবাইলে লোকেশন রিকোয়েস্ট সফলভাবে পাঠানো হয়েছে!`);
        setTimeout(() => setReqActionMsg(""), 4000);
        fetchAdminData();
      } else {
        alert(data.error || "রিকোয়েস্ট পাঠানো যায়নি");
      }
    } catch {
      alert("সমস্যা হয়েছে");
    }
  };

  // 99 Delete or Edit Message from Admin Panel
  const handleAdminDeleteMessage = async (msgId: number) => {
    if (!confirm("আপনি কি নিশ্চিত এই মেসেজটি ডিলিট করতে চান?")) return;
    try {
      const res = await fetch("/api/messages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messageId: msgId,
          userId: currentUser.id,
          action: "delete",
        }),
      });
      if (res.ok) {
        setMessagesList((prev) => prev.filter((m) => m.id !== msgId));
      }
    } catch {
      alert("ডিলিট করতে সমস্যা হয়েছে");
    }
  };

  const handleAdminEditMessage = async (msgId: number, oldContent: string) => {
    const newContent = window.prompt("মেসেজ পরিবর্তন করুন:", oldContent);
    if (newContent === null || !newContent.trim()) return;

    try {
      const res = await fetch("/api/messages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messageId: msgId,
          userId: currentUser.id,
          content: newContent.trim(),
        }),
      });
      if (res.ok) {
        setMessagesList((prev) =>
          prev.map((m) => (m.id === msgId ? { ...m, content: newContent.trim() } : m))
        );
      }
    } catch {
      alert("এডিট ব্যর্থ হয়েছে");
    }
  };

  if (!currentUser) {
    return <div className="min-h-screen bg-black" />;
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col relative overflow-hidden select-none">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-green-500/10 blur-[130px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-yellow-500/5 blur-[130px] pointer-events-none" />

      {/* Header */}
      <header className="sticky top-0 z-30 bg-black/95 backdrop-blur-xl border-b border-green-500/30 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => router.push(`/chat-list?userId=${currentUser.id}`)}
            className="p-1.5 rounded-full hover:bg-green-500/20 text-green-400 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xl">👑</span>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base font-extrabold text-white tracking-wide">
                  Hii pro <span className="text-green-400">Admin 99</span>
                </h1>
                <span className="bg-yellow-500/20 text-yellow-300 text-[10px] font-bold px-1.5 rounded-full border border-yellow-500/40">
                  Master Control
                </span>
              </div>
              <p className="text-[10px] text-green-500/70">ইউজার, মেসেজ, ডিভাইস ও লাইভ লোকেশন ট্র্যাকিং</p>
            </div>
          </div>
        </div>

        <button
          onClick={fetchAdminData}
          className="p-2 text-green-400 hover:text-green-300 rounded-full hover:bg-green-500/10"
          title="Refresh Data"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </header>

      {/* Toast Notice */}
      {reqActionMsg && (
        <div className="bg-blue-950/90 border-b border-blue-500/60 px-4 py-2 text-xs text-blue-200 text-center font-bold animate-in fade-in z-20">
          ✓ {reqActionMsg}
        </div>
      )}

      {/* Quick Stats Grid */}
      <div className="px-4 py-3 grid grid-cols-4 gap-2 relative z-10 text-center">
        <div className="bg-black/70 border border-green-500/30 rounded-2xl p-2 shadow-[0_0_15px_rgba(0,255,65,0.1)]">
          <span className="text-[9px] text-green-400/80 block uppercase">মোট ইউজার</span>
          <span className="text-base font-extrabold font-mono text-white">{stats.totalUsers}</span>
        </div>

        <div className="bg-black/70 border border-green-500/30 rounded-2xl p-2 shadow-[0_0_15px_rgba(0,255,65,0.1)]">
          <span className="text-[9px] text-green-400/80 block uppercase">মেসেজ সংখ্যা</span>
          <span className="text-base font-extrabold font-mono text-white">{stats.totalMessages}</span>
        </div>

        <div className="bg-black/70 border border-blue-500/30 rounded-2xl p-2 shadow-[0_0_15px_rgba(59,130,246,0.1)]">
          <span className="text-[9px] text-blue-300 block uppercase">শেয়ার্ড লোকেশন</span>
          <span className="text-base font-extrabold font-mono text-blue-400">
            {locationRequests.filter((l) => l.status === "approved").length}
          </span>
        </div>

        <div className="bg-black/70 border border-yellow-500/30 rounded-2xl p-2 shadow-[0_0_15px_rgba(255,215,0,0.1)]">
          <span className="text-[9px] text-yellow-400/80 block uppercase">গ্রুপ পিন</span>
          <span className="text-base font-extrabold font-mono text-yellow-300 tracking-wider">{stats.groupPin}</span>
        </div>
      </div>

      {/* Nav Tabs */}
      <div className="px-3 pt-1 pb-2 border-b border-green-500/20 flex gap-1.5 relative z-10 overflow-x-auto">
        <button
          onClick={() => setActiveTab("users")}
          className={`px-3 py-2 text-[11px] font-bold rounded-xl whitespace-nowrap transition-all ${
            activeTab === "users"
              ? "bg-green-500 text-black shadow-[0_0_15px_rgba(0,255,65,0.4)]"
              : "bg-black/60 text-green-400/70 border border-green-500/20 hover:border-green-400"
          }`}
        >
          📱 ইউজার ও মোবাইল ({usersList.length})
        </button>

        <button
          onClick={() => setActiveTab("locations")}
          className={`px-3 py-2 text-[11px] font-bold rounded-xl whitespace-nowrap transition-all ${
            activeTab === "locations"
              ? "bg-blue-500 text-black shadow-[0_0_15px_rgba(59,130,246,0.4)]"
              : "bg-black/60 text-blue-300/80 border border-blue-500/20 hover:border-blue-400"
          }`}
        >
          📍 লাইভ লোকেশন ({locationRequests.length})
        </button>

        <button
          onClick={() => setActiveTab("messages")}
          className={`px-3 py-2 text-[11px] font-bold rounded-xl whitespace-nowrap transition-all ${
            activeTab === "messages"
              ? "bg-green-500 text-black shadow-[0_0_15px_rgba(0,255,65,0.4)]"
              : "bg-black/60 text-green-400/70 border border-green-500/20 hover:border-green-400"
          }`}
        >
          💬 মেসেজ ও ছবি
        </button>

        <button
          onClick={() => setActiveTab("settings")}
          className={`px-3 py-2 text-[11px] font-bold rounded-xl whitespace-nowrap transition-all ${
            activeTab === "settings"
              ? "bg-green-500 text-black shadow-[0_0_15px_rgba(0,255,65,0.4)]"
              : "bg-black/60 text-green-400/70 border border-green-500/20 hover:border-green-400"
          }`}
        >
          ⚙️ ইউজার লিমিট
        </button>
      </div>

      {/* Main Tab Content */}
      <main className="flex-1 overflow-y-auto px-4 py-3 relative z-10 pb-10">
        {loading ? (
          <div className="py-20 text-center text-green-500/60 text-xs">ডাটা লোড হচ্ছে...</div>
        ) : activeTab === "users" ? (
          /* TAB 1: USERS & MOBILE DEVICES & SEND LOCATION BUTTON */
          <div className="space-y-2.5">
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs text-green-400 font-bold">
                কোন ইউজার কোন মোবাইল থেকে যুক্ত ও লাইভ লোকেশন রিকোয়েস্ট:
              </span>
              <span className="text-[10px] text-green-500/70">
                মোট {usersList.length}/{maxLimitInput}
              </span>
            </div>

            {usersList.map((u) => {
              const isSpecial = u.username === "99";
              return (
                <div
                  key={u.id}
                  className={`p-3 rounded-2xl border transition-all ${
                    isSpecial
                      ? "bg-yellow-950/20 border-yellow-500/40 shadow-[0_0_15px_rgba(255,215,0,0.1)]"
                      : "bg-black/60 border-green-500/30 hover:border-green-400"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-11 h-11 rounded-full border-2 flex items-center justify-center font-mono font-bold text-sm ${
                          isSpecial
                            ? "border-yellow-400 text-yellow-300 bg-yellow-950/50"
                            : "border-green-400 text-green-300 bg-black"
                        }`}
                      >
                        {u.avatarUrl ? (
                          <img src={u.avatarUrl} alt="Avatar" className="w-full h-full object-cover rounded-full" />
                        ) : (
                          u.username
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-white font-bold text-sm">
                            ইউজার নম্বর: <span className="text-green-300 font-mono">{u.username}</span>
                          </span>
                          {isSpecial && (
                            <span className="bg-yellow-500/20 text-yellow-300 text-[9px] font-bold px-1.5 rounded-full border border-yellow-500/40">
                              এডমিন
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-green-400/80">{u.displayName || `User ${u.username}`}</p>
                      </div>
                    </div>

                    {/* Location Request Action Button */}
                    {!isSpecial && (
                      <button
                        onClick={() => handleSendLocationReqToUser(u.id, u.username)}
                        className="px-2.5 py-1 rounded-xl bg-blue-500/20 border border-blue-400 text-blue-300 hover:bg-blue-500/30 text-[11px] font-bold flex items-center gap-1 transition-all shadow-[0_0_10px_rgba(59,130,246,0.3)]"
                      >
                        <span>📍 লোকেশন রিকোয়েস্ট</span>
                      </button>
                    )}
                  </div>

                  {/* Device & Mobile Model Details */}
                  <div className="mt-2.5 pt-2 border-t border-green-500/20 flex flex-wrap items-center justify-between text-[11px] gap-2">
                    <div className="flex items-center gap-1 text-green-300">
                      <span className="text-sm">📱</span>
                      <span className="font-semibold">মোবাইল মডেল:</span>
                      <span className="text-green-400 bg-green-950/50 border border-green-500/30 px-2 py-0.5 rounded-md font-mono text-[10px]">
                        {u.deviceInfo || "অজানা মোবাইল / ব্রাউজার"}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-green-500/70 text-[10px] font-mono">
                      <span>IP: {u.lastIp || "127.0.0.1"}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : activeTab === "locations" ? (
          /* TAB 2: LIVE LOCATIONS SHARED WITH 99 ONLY */
          <div className="space-y-2.5">
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs text-blue-300 font-bold">
                ইউজারদের শেয়ার করা লাইভ লোকেশন (শুধুমাত্র ৯৯ দেখতে পাচ্ছে):
              </span>
              <span className="text-[10px] text-blue-400/80">লাইভ ম্যাপ ট্র্যাকিং</span>
            </div>

            {locationRequests.length === 0 ? (
              <div className="text-center py-16 text-xs text-green-500/60">
                <p>কোনো লোকেশন রিকোয়েস্ট রেকর্ড পাওয়া যায়নি।</p>
                <p className="text-[10px] text-green-500/40 mt-1">
                  ইউজার ট্যাবে গিয়ে যেকোনো ইউজারের পাশে '📍 লোকেশন রিকোয়েস্ট' বাটনে চাপ দিন।
                </p>
              </div>
            ) : (
              locationRequests.map((loc) => {
                const isApproved = loc.status === "approved";
                const isPending = loc.status === "pending";

                return (
                  <div
                    key={loc.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isApproved
                        ? "bg-blue-950/30 border-blue-400/60 shadow-[0_0_20px_rgba(59,130,246,0.2)]"
                        : isPending
                        ? "bg-yellow-950/20 border-yellow-500/40"
                        : "bg-red-950/20 border-red-500/30"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-base">📍</span>
                        <span className="font-bold text-white text-sm font-mono">
                          User {loc.targetUsername}
                        </span>
                        <span className="text-xs text-green-400/80">
                          ({loc.targetDisplayName || `User ${loc.targetUsername}`})
                        </span>
                      </div>

                      {/* Status Badge */}
                      {isApproved ? (
                        <span className="bg-green-500/20 text-green-300 border border-green-400 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                          লোকেশন অনুমোদিত
                        </span>
                      ) : isPending ? (
                        <span className="bg-yellow-500/20 text-yellow-300 border border-yellow-400 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          অনুমোদনের অপেক্ষায়...
                        </span>
                      ) : (
                        <span className="bg-red-500/20 text-red-400 border border-red-400 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                          অনুমতি বাতিল
                        </span>
                      )}
                    </div>

                    {/* Coordinates & Google Map Links (ONLY visible to 99) */}
                    {isApproved && loc.latitude && loc.longitude ? (
                      <div className="space-y-2 mt-2 pt-2 border-t border-blue-500/20">
                        <div className="bg-black/60 rounded-xl p-2.5 text-xs font-mono space-y-1">
                          <div className="text-green-300 font-semibold flex items-center justify-between">
                            <span>অক্ষাংশ (Latitude): {loc.latitude}</span>
                            <span>দ্রাঘিমাংশ (Longitude): {loc.longitude}</span>
                          </div>
                          {loc.accuracy && (
                            <p className="text-[10px] text-green-500/70">
                              পরিমাপ নির্ভুলতা (Accuracy): ±{Math.round(loc.accuracy)} মিটার
                            </p>
                          )}
                        </div>

                        {/* Open Google Maps Button */}
                        <a
                          href={`https://www.google.com/maps?q=${loc.latitude},${loc.longitude}`}
                          target="_blank"
                          rel="noreferrer"
                          className="w-full py-2 rounded-xl bg-gradient-to-r from-blue-500 to-green-500 text-black font-extrabold text-xs shadow-[0_0_15px_rgba(59,130,246,0.5)] flex items-center justify-center gap-1.5 hover:scale-[1.01] transition-all"
                        >
                          <span>🗺️ গুগল ম্যাপে লাইভ লোকেশন দেখুন (Google Maps)</span>
                        </a>
                      </div>
                    ) : (
                      <p className="text-[11px] text-green-500/60 mt-1">
                        {isPending
                          ? "ইউজারের মোবাইলে পপআপ পাঠানো হয়েছে। ইউজার এলাও (Allow) বাটনে চাপ দিলেই এখানে ম্যাপ ওপেন হবে।"
                          : "ইউজার লোকেশন শেয়ারিং রিকোয়েস্ট বাতিল করেছে।"}
                      </p>
                    )}

                    <div className="mt-2 text-[10px] text-green-500/50 flex items-center justify-between font-mono pt-1">
                      <span>📱 {loc.targetDevice || "Mobile"}</span>
                      <span>
                        রিকোয়েস্ট সময়: {new Date(loc.requestedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        ) : activeTab === "messages" ? (
          /* TAB 3: MESSAGES & PHOTO CONTROL */
          <div className="space-y-2.5">
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs text-green-400 font-bold">
                ইউজাররা কি মেসেজ ও ছবি পাঠাচ্ছে (কন্ট্রোল প্যানেল):
              </span>
              <span className="text-[10px] text-green-500/70">লাইভ আপডেট</span>
            </div>

            {messagesList.length === 0 ? (
              <p className="text-center py-12 text-xs text-green-500/60">কোনো মেসেজ নেই</p>
            ) : (
              messagesList.map((m) => (
                <div
                  key={m.id}
                  className="p-3 rounded-2xl bg-black/60 border border-green-500/30 space-y-2 hover:border-green-400 transition-all"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-green-300 font-mono">User {m.senderUsername}</span>
                      <span className="text-green-500/50 text-[10px]">➔ Chat with {m.contactNumber}</span>
                      {m.isPrivateTo99 && (
                        <span className="bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 text-[9px] px-1.5 rounded-full font-bold">
                          🔒 সিক্রেট ছবি (শুধুমাত্র ৯৯ দেখতে পাচ্ছে)
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-green-500/60 font-mono">
                      {new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>

                  {m.type === "image" && m.imageUrl ? (
                    <div className="rounded-xl border border-green-500/40 p-1 bg-black/80 inline-block">
                      <img
                        src={m.imageUrl}
                        alt="Shared"
                        className="rounded-lg max-h-48 max-w-xs object-cover cursor-pointer hover:opacity-95"
                        onClick={() => window.open(m.imageUrl!, "_blank")}
                      />
                      <span className="text-[10px] text-green-400 block pt-1 px-1 font-mono">
                        📷 ছবি বড় করে দেখতে ক্লিক করুন
                      </span>
                    </div>
                  ) : (
                    <p className="text-xs text-green-200 bg-green-950/20 border border-green-500/20 rounded-xl px-3 py-2">
                      {m.content}
                    </p>
                  )}

                  <div className="flex items-center justify-between pt-1 border-t border-green-500/15 text-[10px]">
                    <span className="text-green-500/70 font-mono truncate max-w-[200px]">
                      📱 {m.senderDevice || "Mobile"}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleAdminEditMessage(m.id, m.content)}
                        className="px-2 py-1 rounded bg-yellow-500/20 border border-yellow-500/40 text-yellow-300 hover:bg-yellow-500/30 transition-all font-semibold"
                      >
                        ✏️ এডিট
                      </button>
                      <button
                        onClick={() => handleAdminDeleteMessage(m.id)}
                        className="px-2 py-1 rounded bg-red-500/20 border border-red-500/40 text-red-400 hover:bg-red-500/30 transition-all font-semibold"
                      >
                        🗑️ ডিলিট
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          /* TAB 4: SYSTEM SETTINGS & USER LIMIT */
          <div className="space-y-4 max-w-md mx-auto">
            <div className="bg-black/70 border border-green-500/40 rounded-3xl p-5 shadow-[0_0_30px_rgba(0,255,65,0.15)] space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-green-500/20">
                <span className="text-xl">⚙️</span>
                <div>
                  <h3 className="text-sm font-extrabold text-white">ইউজার রেজিস্ট্রেশন লিমিট নির্ধারণ</h3>
                  <p className="text-[11px] text-green-400/80">
                    ৯৯ ইউজার নিজে নির্ধারণ করবে সর্বোচ্চ কতজন অ্যাকাউন্ট খুলতে পারবে
                  </p>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-green-300 font-bold block">
                  সর্বোচ্চ কয়জন অ্যাকাউন্ট খুলতে পারবে (Max User Limit):
                </label>
                <input
                  type="number"
                  min={1}
                  max={99}
                  value={maxLimitInput}
                  onChange={(e) => setMaxLimitInput(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-black/60 border border-green-500/50 rounded-2xl px-4 py-2.5 text-base font-mono font-bold text-green-300 focus:outline-none focus:border-green-400 focus:shadow-[0_0_20px_rgba(0,255,65,0.4)]"
                />
                <p className="text-[10px] text-green-500/60">
                  * বর্তমানে মোট অ্যাকাউন্ট আছে: <strong className="text-white">{usersList.length}</strong> জন।
                  আপনি যা সেট করবেন তার উপরে কেউ আর নতুন অ্যাকাউন্ট খুলতে পারবে না।
                </p>
              </div>

              <div className="flex items-center justify-between p-3 rounded-2xl bg-green-950/20 border border-green-500/30">
                <div>
                  <span className="text-xs font-bold text-white block">নতুন অ্যাকাউন্ট খোলা অন/অফ</span>
                  <span className="text-[10px] text-green-500/70">
                    {regEnabled ? "নতুন অ্যাকাউন্ট খোলা চালু আছে" : "নতুন অ্যাকাউন্ট খোলা সাময়িক বন্ধ"}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setRegEnabled(!regEnabled)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    regEnabled ? "bg-green-500" : "bg-red-950 border border-red-500/40"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 w-5 h-5 rounded-full bg-black transition-transform ${
                      regEnabled ? "right-0.5" : "left-0.5"
                    }`}
                  />
                </button>
              </div>

              {saveStatus && (
                <div className="bg-green-950/50 border border-green-400/60 rounded-xl py-2 px-3 text-center text-xs text-green-300 font-bold">
                  {saveStatus}
                </div>
              )}

              <button
                onClick={handleSaveSettings}
                className="w-full py-3 rounded-full bg-gradient-to-r from-green-400 to-green-500 text-black font-bold text-xs shadow-[0_0_25px_rgba(0,255,65,0.6)] hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                সেভ করুন (Save Limit & Settings)
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
