export default function Loading() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-green-400 animate-pulse">Loading...</div>
    </div>
  );
}
