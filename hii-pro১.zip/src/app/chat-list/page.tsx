"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { LocationRequestModal } from "@/components/LocationRequestModal";

export const dynamic = "force-dynamic";

interface ChatItem {
  id: number;
  contactNumber: string;
  contactName: string;
  lastMessage: string | null;
  lastMessageAt: string;
  unreadCount: number;
}

interface CheckedUser {
  id: number;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  isOnline: boolean;
  lastActiveAt: string;
}

export default function ChatListPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [chats, setChats] = useState<ChatItem[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // Search check states
  const [searchResult, setSearchResult] = useState<CheckedUser | null>(null);
  const [searchNotFoundMsg, setSearchNotFoundMsg] = useState<string | null>(null);
  const [checkingUser, setCheckingUser] = useState(false);

  // Load user session
  useEffect(() => {
    let user = null;
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) user = JSON.parse(saved);
    } catch {}

    if (!user) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          user = JSON.parse(decodeURIComponent(match[1]));
        } catch {}
      }
    }

    if (!user || !user.id) {
      fetch("/api/auth/me")
        .then((r) => r.json())
        .then((data) => {
          if (data.user) {
            setCurrentUser(data.user);
            localStorage.setItem("hii_pro_user", JSON.stringify(data.user));
          } else {
            router.replace("/login");
          }
        })
        .catch(() => router.replace("/login"));
    } else {
      setCurrentUser(user);
    }
  }, [router]);

  // Real-time Heartbeat: Send every 20 seconds to keep online status accurate
  useEffect(() => {
    if (!currentUser?.id) return;

    const sendHeartbeat = async (online: boolean) => {
      try {
        await fetch("/api/user/heartbeat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: currentUser.id, isOnline: online }),
        });
      } catch {}
    };

    sendHeartbeat(true);
    const interval = setInterval(() => sendHeartbeat(true), 20000);

    const handleBeforeUnload = () => {
      // Send offline on exit
      if (navigator.sendBeacon) {
        const blob = new Blob(
          [JSON.stringify({ userId: currentUser.id, isOnline: false })],
          { type: "application/json" }
        );
        navigator.sendBeacon("/api/user/heartbeat", blob);
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      clearInterval(interval);
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [currentUser]);

  // Fetch chats from API
  const fetchChats = useCallback(async () => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/chats");
      const data = await res.json();
      if (data.chats) {
        setChats(data.chats);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    if (currentUser) {
      fetchChats();
      const interval = setInterval(fetchChats, 6000);
      return () => clearInterval(interval);
    }
  }, [currentUser, fetchChats]);

  // Requirement 1: Search box validation
  // If user enters a 2-digit number (e.g. 98) in search box:
  // Check if account exists and is active.
  // If NOT exists: "এই নামে এখনো ইউজার একটিভ হয়নি" -> User CANNOT message them!
  useEffect(() => {
    const trimmed = search.trim();
    if (/^\d{2}$/.test(trimmed)) {
      setCheckingUser(true);
      fetch(`/api/user/check?username=${trimmed}`)
        .then((r) => r.json())
        .then((data) => {
          setCheckingUser(false);
          if (data.exists && data.user) {
            setSearchResult(data.user);
            setSearchNotFoundMsg(null);
          } else {
            setSearchResult(null);
            setSearchNotFoundMsg(`এই নামে (${trimmed}) এখনো ইউজার একটিভ হয়নি`);
          }
        })
        .catch(() => {
          setCheckingUser(false);
        });
    } else {
      setSearchResult(null);
      setSearchNotFoundMsg(null);
      setCheckingUser(false);
    }
  }, [search]);

  // Start new chat with validated user only
  const handleStartValidatedChat = async (targetUsername: string) => {
    try {
      const res = await fetch("/api/chats", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contactNumber: targetUsername,
          contactName: `User ${targetUsername}`,
        }),
      });
      const data = await res.json();
      if (data.chat) {
        router.push(`/chat-room/${targetUsername}?userId=${currentUser.id}`);
      }
    } catch {
      alert("চ্যাট শুরু করা সম্ভব হয়নি");
    }
  };

  // Add new chat by 2-digit number (validates existence first!)
  const handleAddNewChat = async () => {
    const input = window.prompt("নতুন চ্যাট শুরু করতে যেকোনো ২ সংখ্যার নম্বর লিখুন (যেমন: 99, 85):");
    if (!input) return;

    const num = input.replace(/\D/g, "").slice(0, 2);
    if (num.length !== 2) {
      alert("শুধুমাত্র ২ অঙ্কের নম্বর দিন!");
      return;
    }

    // Verify if this user exists and is active!
    try {
      const checkRes = await fetch(`/api/user/check?username=${num}`);
      const checkData = await checkRes.json();

      if (!checkData.exists) {
        alert("এই নামে এখনো ইউজার একটিভ হয়নি। এই ইউজার নামে কোনো মেসেজ দেওয়া যাবে না!");
        return;
      }

      const res = await fetch("/api/chats", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactNumber: num, contactName: `User ${num}` }),
      });
      const data = await res.json();
      if (data.chat) {
        router.push(`/chat-room/${num}?userId=${currentUser.id}`);
      }
    } catch {
      alert("চ্যাট তৈরি করা সম্ভব হয়নি");
    }
  };

  const filteredChats = chats.filter(
    (c) =>
      c.contactNumber.includes(search) ||
      (c.contactName && c.contactName.toLowerCase().includes(search.toLowerCase())) ||
      (c.lastMessage && c.lastMessage.toLowerCase().includes(search.toLowerCase()))
  );

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center text-green-400">
        <div className="w-10 h-10 border-2 border-green-500 border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs">লোড হচ্ছে...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col relative overflow-hidden select-none">
      {/* Location Request Modal for regular users (if 99 requested location) */}
      <LocationRequestModal currentUserId={currentUser.id} />

      {/* Background glow effects */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-green-500/10 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/3 left-0 w-80 h-80 bg-green-500/10 blur-[100px] pointer-events-none" />

      {/* Header - strictly NO phone status bar (no wifi/time/battery) */}
      <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-lg border-b border-green-500/20 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Crown chat logo */}
          <div className="w-10 h-10 rounded-full border border-green-400/80 bg-black flex items-center justify-center shadow-[0_0_15px_rgba(0,255,65,0.4)]">
            <span className="text-sm">👑</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-300 to-green-500">
                Hii pro
              </h1>
              {currentUser.isSpecialUser && (
                <span className="bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 text-[9px] font-bold px-1.5 py-0.2 rounded-full">
                  Admin 99
                </span>
              )}
            </div>
            {/* Real-time active status of current logged in user */}
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_6px_#00ff41]" />
              <span className="text-[11px] text-green-400 font-medium">Online ({currentUser.username})</span>
            </div>
          </div>
        </div>

        {/* User avatar / profile button & 99 Admin Button */}
        <div className="flex items-center gap-2">
          {currentUser.isSpecialUser && (
            <button
              onClick={() => router.push(`/admin?userId=${currentUser.id}`)}
              className="px-2.5 py-1 rounded-full bg-yellow-500/20 border border-yellow-400 text-yellow-300 text-xs font-bold hover:bg-yellow-500/30 shadow-[0_0_12px_rgba(255,215,0,0.4)] flex items-center gap-1 transition-all"
              title="Admin Panel"
            >
              <span>👑 এডমিন</span>
            </button>
          )}

          <div
            onClick={() => router.push(`/more?userId=${currentUser.id}`)}
            className="cursor-pointer"
          >
            <div className="w-9 h-9 rounded-full border-2 border-green-400 bg-green-950/60 flex items-center justify-center text-xs font-bold text-green-300 overflow-hidden shadow-[0_0_12px_rgba(0,255,65,0.4)]">
              {currentUser.avatarUrl ? (
                <img src={currentUser.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <span>{currentUser.username}</span>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="px-4 py-3 relative z-10 space-y-2">
        <div className="relative">
          <svg className="w-4 h-4 text-green-400/60 absolute left-4 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats by 2-digit number..."
            className="w-full bg-black/60 border border-green-500/30 rounded-full pl-11 pr-4 py-2.5 text-sm text-green-300 placeholder-green-600/70 focus:outline-none focus:border-green-400 focus:shadow-[0_0_20px_rgba(0,255,65,0.3)] transition-all font-mono"
          />
        </div>

        {/* Live Search User Validation Card */}
        {checkingUser && (
          <div className="text-[11px] text-green-400/70 px-3 py-1 flex items-center gap-1.5 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-green-400" />
            <span>ইউজার সক্রিয়তা চেক করা হচ্ছে...</span>
          </div>
        )}

        {/* NOT ACTIVE WARNING - User cannot message! */}
        {searchNotFoundMsg && (
          <div className="p-3 rounded-2xl bg-red-950/80 border border-red-500/60 shadow-[0_0_20px_rgba(239,68,68,0.25)] animate-in fade-in flex items-center gap-3">
            <span className="text-xl">⚠️</span>
            <div className="flex-1">
              <p className="text-xs font-bold text-red-200">{searchNotFoundMsg}</p>
              <p className="text-[10px] text-red-400/80 mt-0.5">
                এই নম্বরে অ্যাকাউন্ট খোলা নেই, তাই কোনো মেসেজ পাঠানো যাবে না।
              </p>
            </div>
          </div>
        )}

        {/* ACTIVE USER FOUND IN SEARCH - Show Active status & chat button */}
        {searchResult && (
          <div className="p-3 rounded-2xl bg-green-950/40 border border-green-400/70 shadow-[0_0_20px_rgba(0,255,65,0.3)] animate-in fade-in flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full border-2 border-green-400 bg-black flex items-center justify-center font-mono font-bold text-sm text-green-300">
                {searchResult.username}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white font-mono">User {searchResult.username}</span>
                  {/* Real-time active status indicator */}
                  {searchResult.isOnline ? (
                    <span className="flex items-center gap-1 bg-green-500/20 text-green-400 border border-green-500/40 text-[9px] font-bold px-1.5 py-0.5 rounded-full">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                      অ্যাক্টিভ (Online)
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 bg-red-500/10 text-red-400 border border-red-500/30 text-[9px] font-semibold px-1.5 py-0.5 rounded-full">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-400/80" />
                      অফলাইন (Offline)
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-green-400/70">এই অ্যাকাউন্ট সক্রিয় আছে</p>
              </div>
            </div>

            <button
              onClick={() => handleStartValidatedChat(searchResult.username)}
              className="px-3.5 py-1.5 rounded-full bg-green-500 text-black text-xs font-bold shadow-[0_0_15px_rgba(0,255,65,0.5)] hover:bg-green-400 transition-all"
            >
              মেসেজ করুন
            </button>
          </div>
        )}
      </div>

      {/* Chat List Area */}
      <main className="flex-1 overflow-y-auto px-4 pb-24 relative z-10">
        {loading ? (
          <div className="py-20 text-center text-green-500/60 text-xs">চ্যাট লোড হচ্ছে...</div>
        ) : filteredChats.length === 0 && !searchResult ? (
          <div className="py-16 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full border border-green-500/30 bg-green-950/20 flex items-center justify-center mb-4 text-2xl shadow-[0_0_25px_rgba(0,255,65,0.2)]">
              💬
            </div>
            <p className="text-green-300 font-semibold text-sm">কোনো চ্যাট নেই</p>
            <p className="text-green-500/60 text-xs mt-1 max-w-xs">
              সার্চ বক্সে ২ সংখ্যার নম্বর লিখুন অথবা নিচের (+) বাটনে ট্যাপ করে সক্রিয় ইউজারের সাথে চ্যাট শুরু করুন।
            </p>
            <button
              onClick={handleAddNewChat}
              className="mt-4 px-5 py-2 rounded-full bg-green-500 text-black text-xs font-bold shadow-[0_0_20px_rgba(0,255,65,0.5)] hover:bg-green-400 transition-all"
            >
              + নতুন চ্যাট যোগ করুন
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {filteredChats.map((chat) => {
              const is99 = chat.contactNumber === "99";
              return (
                <div
                  key={chat.id}
                  onClick={() => router.push(`/chat-room/${chat.contactNumber}?userId=${currentUser.id}`)}
                  className="group flex items-center gap-3.5 p-3 rounded-2xl bg-black/50 border border-green-500/20 hover:border-green-400 hover:bg-green-950/20 transition-all cursor-pointer shadow-[0_0_15px_rgba(0,0,0,0.5)] hover:shadow-[0_0_25px_rgba(0,255,65,0.2)]"
                >
                  {/* Glowing 2-digit Avatar Circle */}
                  <div className="relative">
                    <div
                      className={`w-13 h-13 rounded-full border-2 flex items-center justify-center text-lg font-bold font-mono ${
                        is99
                          ? "border-yellow-400 text-yellow-300 bg-yellow-950/30 shadow-[0_0_20px_rgba(255,215,0,0.5)]"
                          : "border-green-400 text-green-300 bg-black shadow-[0_0_15px_rgba(0,255,65,0.4)]"
                      }`}
                      style={{ width: "50px", height: "50px" }}
                    >
                      {chat.contactNumber}
                    </div>
                  </div>

                  {/* Chat Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="text-white font-bold text-sm tracking-wide">
                          {chat.contactNumber}
                        </span>
                        {is99 && (
                          <span className="text-[10px] bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 px-1.5 rounded-full">
                            Admin
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-green-500/70 font-mono">
                        {chat.lastMessageAt ? new Date(chat.lastMessageAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "Now"}
                      </span>
                    </div>

                    <p className="text-xs text-green-400/70 truncate mt-1">
                      {chat.lastMessage || "ট্যাপ করে মেসেজ পাঠান..."}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Floating Add New Chat (+) Button */}
      <button
        onClick={handleAddNewChat}
        className="fixed bottom-20 right-5 z-40 w-14 h-14 rounded-full bg-gradient-to-r from-green-400 to-green-500 text-black flex items-center justify-center shadow-[0_0_35px_rgba(0,255,65,0.8)] hover:scale-105 active:scale-95 transition-all"
        title="Start New Chat"
      >
        <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.8} d="M12 4v16m8-8H4" />
        </svg>
      </button>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-black/90 backdrop-blur-xl border-t border-green-500/30 px-6 py-2.5">
        <div className="max-w-md mx-auto flex items-center justify-around">
          <button className="flex flex-col items-center gap-1 text-green-400">
            <div className="p-1 rounded-full bg-green-500/20 shadow-[0_0_12px_rgba(0,255,65,0.5)]">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <span className="text-[11px] font-semibold">Chats</span>
          </button>

          <button
            onClick={() => router.push(`/group?userId=${currentUser.id}`)}
            className="flex flex-col items-center gap-1 text-green-500/60 hover:text-green-400 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.127-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.127-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            <span className="text-[11px] font-medium">Group</span>
          </button>

          <button
            onClick={() => router.push(`/invite?userId=${currentUser.id}`)}
            className="flex flex-col items-center gap-1 text-green-500/60 hover:text-green-400 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
            <span className="text-[11px] font-medium">Invite</span>
          </button>

          <button
            onClick={() => router.push(`/more?userId=${currentUser.id}`)}
            className="flex flex-col items-center gap-1 text-green-500/60 hover:text-green-400 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
            <span className="text-[11px] font-medium">More</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
