import { db } from "@/db";
import { autoReplies, users } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return Response.json({ error: "userId required" }, { status: 400 });
    }

    const replies = await db
      .select()
      .from(autoReplies)
      .where(eq(autoReplies.userId, parseInt(userId)));

    return Response.json({ autoReplies: replies });
  } catch {
    return Response.json({ error: "Failed to fetch auto replies" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const { userId, triggerText, responseText } = await req.json();

    const [user] = await db.select().from(users).where(eq(users.id, parseInt(userId))).limit(1);
    if (!user || !user.isSpecialUser) {
      return Response.json({ error: "Only special user can add auto replies" }, { status: 403 });
    }

    const [newReply] = await db.insert(autoReplies).values({
      userId: parseInt(userId),
      triggerText: String(triggerText).trim(),
      responseText: String(responseText).trim(),
    }).returning();

    return Response.json({ autoReply: newReply });
  } catch {
    return Response.json({ error: "Failed to add auto reply" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const userId = searchParams.get("userId");

    if (!id || !userId) {
      return Response.json({ error: "id and userId required" }, { status: 400 });
    }

    const [user] = await db.select().from(users).where(eq(users.id, parseInt(userId))).limit(1);
    if (!user || !user.isSpecialUser) {
      return Response.json({ error: "Only special user can delete auto replies" }, { status: 403 });
    }

    await db.delete(autoReplies).where(eq(autoReplies.id, parseInt(id)));

    return Response.json({ success: true });
  } catch {
    return Response.json({ error: "Failed to delete auto reply" }, { status: 500 });
  }
}
