import { db } from "@/db";
import { messages, chats, users, autoReplies } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { validateHumanFace } from "@/lib/faceDetector";
import { parseDeviceFromUserAgent } from "@/lib/deviceDetector";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const contact = searchParams.get("contact");
    const userId = searchParams.get("userId");

    if (!contact || !userId) {
      return Response.json({ error: "contact and userId required" }, { status: 400 });
    }

    const currentUserIdNum = parseInt(userId);
    const [currentUser] = await db.select().from(users).where(eq(users.id, currentUserIdNum)).limit(1);
    const isCurrent99 = currentUser?.username === "99" || currentUser?.isSpecialUser;

    // Find target user details for real-time online status
    const [targetUser] = await db
      .select({
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        avatarUrl: users.avatarUrl,
        isOnline: users.isOnline,
        lastActiveAt: users.lastActiveAt,
      })
      .from(users)
      .where(eq(users.username, contact))
      .limit(1);

    // Calculate real-time active status
    let isTargetOnline = false;
    if (targetUser) {
      const diffMs = Date.now() - new Date(targetUser.lastActiveAt).getTime();
      isTargetOnline = targetUser.isOnline && diffMs < 60000;
    }

    // Find or create chat record for this contact
    let [chat] = await db.select().from(chats).where(eq(chats.contactNumber, contact)).limit(1);
    if (!chat) {
      const [newChat] = await db.insert(chats).values({
        contactNumber: contact,
        contactName: `User ${contact}`,
        lastMessage: "",
      }).returning();
      chat = newChat;
    }

    const allChatMessages = await db
      .select({
        id: messages.id,
        chatId: messages.chatId,
        senderId: messages.senderId,
        content: messages.content,
        type: messages.type,
        imageUrl: messages.imageUrl,
        isPrivateTo99: messages.isPrivateTo99,
        createdAt: messages.createdAt,
        readBySender: messages.readBySender,
        readByReceiver: messages.readByReceiver,
        senderUsername: users.username,
        senderIsSpecial: users.isSpecialUser,
        senderAvatar: users.avatarUrl,
      })
      .from(messages)
      .innerJoin(users, eq(messages.senderId, users.id))
      .where(eq(messages.chatId, chat.id))
      .orderBy(messages.createdAt);

    // Filter out verification photos sent to 99 so only 99 can see them
    const filteredMessages = allChatMessages.filter((msg) => {
      if (msg.isPrivateTo99 && !isCurrent99) {
        return false;
      }
      return true;
    });

    return Response.json({
      messages: filteredMessages,
      chatId: chat.id,
      targetUser: targetUser
        ? {
            id: targetUser.id,
            username: targetUser.username,
            displayName: targetUser.displayName,
            avatarUrl: targetUser.avatarUrl,
            isOnline: isTargetOnline,
            lastActiveAt: targetUser.lastActiveAt,
          }
        : null,
    });
  } catch (error) {
    console.error("Messages GET error:", error);
    return Response.json({ error: "Failed to fetch messages" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const { contact, senderId, content, type, imageUrl } = await req.json();

    if (!contact || !senderId || (!content && !imageUrl)) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Check sender details
    const [senderUser] = await db.select().from(users).where(eq(users.id, parseInt(senderId))).limit(1);
    const isSender99 = senderUser?.username === "99";

    // Track user active & online on sending message
    const ua = req.headers.get("user-agent") || "";
    if (senderUser) {
      const dev = parseDeviceFromUserAgent(ua);
      await db
        .update(users)
        .set({ lastActiveAt: new Date(), isOnline: true, deviceInfo: dev })
        .where(eq(users.id, senderUser.id));
    }

    // 1. Get or create chat
    let [chat] = await db.select().from(chats).where(eq(chats.contactNumber, contact)).limit(1);
    if (!chat) {
      const [newChat] = await db.insert(chats).values({
        contactNumber: contact,
        contactName: `User ${contact}`,
        lastMessage: content || "Photo",
      }).returning();
      chat = newChat;
    }

    // 2. Count existing messages in this chat
    const existingMsgs = await db
      .select()
      .from(messages)
      .where(eq(messages.chatId, chat.id));

    // Special rule for sending photo to user 99:
    let markAsPrivateTo99 = false;

    if (contact === "99" && !isSender99 && imageUrl) {
      const verification = validateHumanFace(imageUrl);
      if (!verification.isPerson) {
        return Response.json(
          {
            error: verification.reason || "এটি কোনো ব্যক্তির ছবি নয়! ৯৯ কে নিজের মানুষের ছবি প্রদান করতে হবে।",
            isRejectedNonPerson: true,
          },
          { status: 422 }
        );
      }
      markAsPrivateTo99 = true;
    }

    // 3. Insert the user message
    const [newMessage] = await db.insert(messages).values({
      chatId: chat.id,
      senderId: parseInt(senderId),
      content: content || "📷 Photo",
      type: type || (imageUrl ? "image" : "text"),
      imageUrl: imageUrl || null,
      isPrivateTo99: markAsPrivateTo99,
      readBySender: true,
      readByReceiver: true,
    }).returning();

    // Update chat last message
    await db
      .update(chats)
      .set({
        lastMessage: markAsPrivateTo99 ? "📷 যাচাইকরণ ছবি পাঠানো হয়েছে" : (content || "Photo"),
        lastMessageAt: new Date(),
      })
      .where(eq(chats.id, chat.id));

    // 4. Special Logic when contacting user 99 (and sender is NOT 99):
    if (contact === "99" && !isSender99) {
      const [u99] = await db.select().from(users).where(eq(users.username, "99")).limit(1);

      if (u99) {
        // Check if 99 is currently OFFLINE
        const diffMs99 = Date.now() - new Date(u99.lastActiveAt).getTime();
        const is99Online = u99.isOnline && diffMs99 < 60000;

        // If 99 is offline:
        // "আর 99 ইউজার যদি অফলাইন থাকে তাহলে তাকে যে ইউজার মেসেজ দিবে তার এখানে অটোমেটিকলি একটা মেসেজ চলে যাবে:
        // '99 ইউজার এখন অফলাইন আছে দয়া করে কিছুক্ষণ সময় অপেক্ষা করুন'"
        if (!is99Online) {
          const offlineAutoMsg = "99 ইউজার এখন অফলাইন আছে দয়া করে কিছুক্ষণ সময় অপেক্ষা করুন";

          await db.insert(messages).values({
            chatId: chat.id,
            senderId: u99.id,
            content: offlineAutoMsg,
            type: "text",
            isPrivateTo99: false,
            readBySender: true,
            readByReceiver: true,
          });

          await db
            .update(chats)
            .set({ lastMessage: offlineAutoMsg, lastMessageAt: new Date() })
            .where(eq(chats.id, chat.id));
        } else {
          // 99 IS ONLINE:
          // Check first-time welcome message
          const isFirstTime = existingMsgs.length === 0;

          if (isFirstTime) {
            const introNotice = "আপনি কে আপনার পরিচয় দেওয়ার জন্য প্রথমে আপনার একটা ছবি প্রদান করুন";
            const welcomeReply = "Welcome আপনাকে কিভাবে সাহায্য করতে পারি";

            await db.insert(messages).values({
              chatId: chat.id,
              senderId: u99.id,
              content: `${introNotice}\n\n${welcomeReply}`,
              type: "text",
              isPrivateTo99: false,
              readBySender: true,
              readByReceiver: true,
            });

            await db
              .update(chats)
              .set({ lastMessage: welcomeReply, lastMessageAt: new Date() })
              .where(eq(chats.id, chat.id));
          } else {
            // Check auto-replies configured by 99
            const customReplies = await db
              .select()
              .from(autoReplies)
              .where(eq(autoReplies.userId, u99.id));

            const trimmedInput = (content || "").trim().toLowerCase();

            let replyResponse = "";
            for (const rep of customReplies) {
              if (rep.triggerText.trim().toLowerCase() === trimmedInput) {
                replyResponse = rep.responseText;
                break;
              }
            }

            if (!replyResponse && trimmedInput === "hi") {
              replyResponse = "hello";
            }

            if (replyResponse) {
              await db.insert(messages).values({
                chatId: chat.id,
                senderId: u99.id,
                content: replyResponse,
                type: "text",
                isPrivateTo99: false,
                readBySender: true,
                readByReceiver: true,
              });

              await db
                .update(chats)
                .set({ lastMessage: replyResponse, lastMessageAt: new Date() })
                .where(eq(chats.id, chat.id));
            }
          }
        }
      }
    }

    return Response.json({
      success: true,
      message: newMessage,
      isPrivateTo99: markAsPrivateTo99,
      info: markAsPrivateTo99 ? "ছবিটি সফলভাবে ৯৯ এর কাছে পাঠানো হয়েছে (গোপনীয়তা রক্ষার্থে এটি কেবল ৯৯ দেখতে পাবেন)।" : undefined,
    });
  } catch (error) {
    console.error("Messages POST error:", error);
    return Response.json({ error: "Failed to send message" }, { status: 500 });
  }
}

// User 99 edit or delete message
export async function PATCH(req: Request) {
  try {
    const { messageId, content, userId, action } = await req.json();

    const [user] = await db.select().from(users).where(eq(users.id, parseInt(userId))).limit(1);
    if (!user || !user.isSpecialUser) {
      return Response.json({ error: "শুধুমাত্র ৯৯ ইউজার এটি নিয়ন্ত্রণ করতে পারবে" }, { status: 403 });
    }

    if (action === "delete") {
      await db.delete(messages).where(eq(messages.id, parseInt(messageId)));
      return Response.json({ success: true, message: "মেসেজ মুছে ফেলা হয়েছে" });
    }

    const [updated] = await db
      .update(messages)
      .set({ content })
      .where(eq(messages.id, parseInt(messageId)))
      .returning();

    return Response.json({ message: updated });
  } catch {
    return Response.json({ error: "Failed to process message action" }, { status: 500 });
  }
}
