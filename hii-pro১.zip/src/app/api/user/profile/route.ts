import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const { userId, avatarUrl, displayName } = await req.json();

    if (!userId) {
      return Response.json({ error: "userId required" }, { status: 400 });
    }

    const updateData: { avatarUrl?: string; displayName?: string } = {};
    if (avatarUrl !== undefined) updateData.avatarUrl = avatarUrl;
    if (displayName !== undefined) updateData.displayName = displayName;

    const [updated] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, parseInt(userId)))
      .returning();

    if (!updated) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    const sessionData = {
      id: updated.id,
      username: updated.username,
      isSpecialUser: updated.isSpecialUser,
      displayName: updated.displayName || `User ${updated.username}`,
      avatarUrl: updated.avatarUrl || "",
    };

    const cookieString = `hii_pro_user=${encodeURIComponent(
      JSON.stringify(sessionData)
    )}; Path=/; Max-Age=315360000; SameSite=Lax`;

    return new Response(
      JSON.stringify({ success: true, user: sessionData }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Set-Cookie": cookieString,
        },
      }
    );
  } catch (error) {
    console.error("Profile update error:", error);
    return Response.json({ error: "Failed to update profile" }, { status: 500 });
  }
}
