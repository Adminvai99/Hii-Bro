import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { parseDeviceFromUserAgent } from "@/lib/deviceDetector";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const { userId, isOnline } = await req.json();

    if (!userId) {
      return Response.json({ error: "userId required" }, { status: 400 });
    }

    const ua = req.headers.get("user-agent") || "";
    const detectedDevice = parseDeviceFromUserAgent(ua);
    const forwarded = req.headers.get("x-forwarded-for");
    const ip = forwarded ? forwarded.split(",")[0].trim() : "127.0.0.1";

    const [u] = await db
      .update(users)
      .set({
        lastActiveAt: new Date(),
        isOnline: isOnline !== undefined ? Boolean(isOnline) : true,
        deviceInfo: detectedDevice,
        lastIp: ip,
      })
      .where(eq(users.id, parseInt(userId)))
      .returning({
        id: users.id,
        username: users.username,
        isOnline: users.isOnline,
        lastActiveAt: users.lastActiveAt,
      });

    return Response.json({ success: true, user: u });
  } catch (error) {
    console.error("Heartbeat error:", error);
    return Response.json({ error: "Heartbeat failed" }, { status: 500 });
  }
}
