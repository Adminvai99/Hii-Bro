import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const username = searchParams.get("username")?.trim();

    if (!username) {
      return Response.json({ error: "username parameter required" }, { status: 400 });
    }

    const [targetUser] = await db
      .select({
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        avatarUrl: users.avatarUrl,
        isOnline: users.isOnline,
        lastActiveAt: users.lastActiveAt,
        isSpecialUser: users.isSpecialUser,
      })
      .from(users)
      .where(eq(users.username, username))
      .limit(1);

    if (!targetUser) {
      return Response.json({
        exists: false,
        message: "এই নামে এখনো ইউজার একটিভ হয়নি",
      });
    }

    // Determine real-time active status:
    // Considered active if isOnline === true AND lastActiveAt was within last 60 seconds
    const diffMs = Date.now() - new Date(targetUser.lastActiveAt).getTime();
    const isActive = targetUser.isOnline && diffMs < 60000;

    return Response.json({
      exists: true,
      user: {
        ...targetUser,
        isOnline: isActive,
      },
    });
  } catch (error) {
    console.error("Check user error:", error);
    return Response.json({ error: "Failed to check user" }, { status: 500 });
  }
}
