import { db } from "@/db";
import { groupSettings, users } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const [user] = await db.select().from(users).where(eq(users.id, parseInt(userId))).limit(1);
    if (!user || !user.isSpecialUser) {
      return Response.json({ error: "Only 99 can view pin" }, { status: 403 });
    }

    const [setting] = await db.select().from(groupSettings).limit(1);
    return Response.json({ pinCode: setting?.pinCode || "2390" });
  } catch {
    return Response.json({ error: "Failed to fetch pin" }, { status: 500 });
  }
}

// Verify PIN
export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const { pin } = await req.json();

    const [setting] = await db.select().from(groupSettings).limit(1);

    if (!setting) {
      return Response.json({ error: "Group not configured" }, { status: 500 });
    }

    if (String(setting.pinCode).trim() === String(pin).trim()) {
      return Response.json({ success: true, groupName: setting.groupName });
    }

    return Response.json({ error: "পিন কোড সঠিক নয়!" }, { status: 401 });
  } catch {
    return Response.json({ error: "PIN verification failed" }, { status: 500 });
  }
}

// User 99 edit PIN
export async function PATCH(req: Request) {
  try {
    await ensureDbSeeded();
    const { userId, newPin } = await req.json();

    if (!userId || !newPin) {
      return Response.json({ error: "Missing fields" }, { status: 400 });
    }

    // Check if user is 99
    const [user] = await db.select().from(users).where(eq(users.id, parseInt(userId))).limit(1);
    if (!user || !user.isSpecialUser) {
      return Response.json({ error: "শুধুমাত্র ৯৯ ইউজার পিন পরিবর্তন করতে পারবেন" }, { status: 403 });
    }

    const [setting] = await db.select().from(groupSettings).limit(1);
    if (setting) {
      await db.update(groupSettings).set({ pinCode: String(newPin).trim() }).where(eq(groupSettings.id, setting.id));
    } else {
      await db.insert(groupSettings).values({ pinCode: String(newPin).trim(), groupName: "Hii pro VIP Group" });
    }

    return Response.json({ success: true, message: "পিন সফলভাবে পরিবর্তন হয়েছে!" });
  } catch {
    return Response.json({ error: "Failed to update pin" }, { status: 500 });
  }
}
