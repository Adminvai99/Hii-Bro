import { db } from "@/db";
import { chats, messages } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureDbSeeded();
    const allChats = await db
      .select({
        id: chats.id,
        contactNumber: chats.contactNumber,
        contactName: chats.contactName,
        lastMessage: chats.lastMessage,
        lastMessageAt: chats.lastMessageAt,
        unreadCount: chats.unreadCount,
        createdAt: chats.createdAt,
      })
      .from(chats)
      .orderBy(desc(chats.lastMessageAt));

    return Response.json({ chats: allChats });
  } catch {
    return Response.json({ error: "Failed to fetch chats" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const { contactNumber, contactName } = await req.json();

    if (!contactNumber || !/^\d{2}$/.test(contactNumber)) {
      return Response.json({ error: "Contact must be 2 digits" }, { status: 400 });
    }

    const existing = await db
      .select()
      .from(chats)
      .where(eq(chats.contactNumber, contactNumber))
      .limit(1);

    if (existing.length > 0) {
      return Response.json({ chat: existing[0] });
    }

    const [newChat] = await db
      .insert(chats)
      .values({
        contactNumber,
        contactName: contactName || `User ${contactNumber}`,
        lastMessage: "",
        unreadCount: 0,
      })
      .returning();

    return Response.json({ chat: newChat });
  } catch {
    return Response.json({ error: "Failed to create chat" }, { status: 500 });
  }
}
