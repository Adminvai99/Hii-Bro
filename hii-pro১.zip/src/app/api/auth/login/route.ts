import { db } from "@/db";
import { users, systemSettings } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { parseDeviceFromUserAgent } from "@/lib/deviceDetector";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    await ensureDbSeeded();

    const body = await req.json();
    const rawUsername = String(body.username || "").trim();
    const password = String(body.password || "").trim();

    // Extract device and IP
    const ua = req.headers.get("user-agent") || "";
    const detectedDevice = parseDeviceFromUserAgent(ua);
    const forwarded = req.headers.get("x-forwarded-for");
    const ip = forwarded ? forwarded.split(",")[0].trim() : "127.0.0.1";

    // Validate username is exactly 2 digits
    if (!/^\d{2}$/.test(rawUsername)) {
      return Response.json(
        { error: "ইউজারনেম শুধুমাত্র যেকোনো ২ সংখ্যার নম্বর হতে হবে (Digits only)" },
        { status: 400 }
      );
    }

    if (!password) {
      return Response.json(
        { error: "পাসওয়ার্ড দিতে হবে" },
        { status: 400 }
      );
    }

    // Check if user exists
    let userList = await db.select().from(users).where(eq(users.username, rawUsername)).limit(1);

    // If user does not exist, check user limit set by 99
    if (userList.length === 0) {
      // 99 is always allowed
      if (rawUsername !== "99") {
        const [sys] = await db.select().from(systemSettings).limit(1);
        const maxLimit = sys?.maxUserLimit ?? 50;
        const regEnabled = sys?.registrationEnabled ?? true;

        if (!regEnabled) {
          return Response.json(
            { error: "এডমিন কর্তৃক নতুন অ্যাকাউন্ট খোলা সাময়িকভাবে বন্ধ আছে।" },
            { status: 403 }
          );
        }

        const countRes = await db.select({ count: sql<number>`count(*)::int` }).from(users);
        const currentCount = countRes[0]?.count || 0;

        if (currentCount >= maxLimit) {
          return Response.json(
            {
              error: `ইউজার লিমিট পূর্ণ হয়েছে! এডমিন ৯৯ কর্তৃক সর্বোচ্চ ${maxLimit} জনের লিমিট নির্ধারণ করা আছে। নতুন অ্যাকাউন্ট খোলা যাবে না।`,
            },
            { status: 403 }
          );
        }
      }

      const is99 = rawUsername === "99";
      const [newUser] = await db
        .insert(users)
        .values({
          username: rawUsername,
          password: password,
          isSpecialUser: is99,
          displayName: `User ${rawUsername}`,
          avatarUrl: "",
          deviceInfo: detectedDevice,
          userAgent: ua,
          lastIp: ip,
          lastActiveAt: new Date(),
        })
        .returning();
      userList = [newUser];
    } else {
      // User already exists - verify password
      const existingUser = userList[0];
      if (existingUser.password !== password) {
        return Response.json(
          { error: "এই ২ সংখ্যার অ্যাকাউন্ট ইতিমধ্যে খোলা আছে। পাসওয়ার্ড সঠিক নয়!" },
          { status: 401 }
        );
      }

      // Update device info and active timestamp on login
      await db
        .update(users)
        .set({
          deviceInfo: detectedDevice,
          userAgent: ua,
          lastIp: ip,
          lastActiveAt: new Date(),
        })
        .where(eq(users.id, existingUser.id));
    }

    const targetUser = userList[0];
    const sessionData = {
      id: targetUser.id,
      username: targetUser.username,
      isSpecialUser: targetUser.isSpecialUser,
      displayName: targetUser.displayName || `User ${targetUser.username}`,
      avatarUrl: targetUser.avatarUrl || "",
    };

    const cookieString = `hii_pro_user=${encodeURIComponent(
      JSON.stringify(sessionData)
    )}; Path=/; Max-Age=315360000; SameSite=Lax`;

    return new Response(
      JSON.stringify({
        success: true,
        user: sessionData,
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Set-Cookie": cookieString,
        },
      }
    );
  } catch (error) {
    console.error("Login error:", error);
    return Response.json({ error: "লগইন করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।" }, { status: 500 });
  }
}
