import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureDbSeeded();

    // Check cookie
    const cookieHeader = req.headers.get("cookie") || "";
    const match = cookieHeader.match(/hii_pro_user=([^;]+)/);
    if (!match) {
      return Response.json({ user: null });
    }

    const decoded = decodeURIComponent(match[1]);
    const parsed = JSON.parse(decoded);

    if (!parsed?.id) {
      return Response.json({ user: null });
    }

    const [dbUser] = await db.select().from(users).where(eq(users.id, parsed.id)).limit(1);
    if (!dbUser) {
      return Response.json({ user: null });
    }

    return Response.json({
      user: {
        id: dbUser.id,
        username: dbUser.username,
        isSpecialUser: dbUser.isSpecialUser,
        displayName: dbUser.displayName || `User ${dbUser.username}`,
        avatarUrl: dbUser.avatarUrl || "",
      },
    });
  } catch {
    return Response.json({ user: null });
  }
}
