import { db } from "@/db";
import { users, messages, chats, autoReplies, groupSettings, systemSettings } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

// Verify requester is 99
async function verify99(userId: string | null) {
  if (!userId) return null;
  const [u] = await db.select().from(users).where(eq(users.id, parseInt(userId))).limit(1);
  if (!u || !u.isSpecialUser) return null;
  return u;
}

export async function GET(req: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");

    const admin = await verify99(userId);
    if (!admin) {
      return Response.json({ error: "অননুমোদিত অ্যাক্সেস! শুধুমাত্র ৯৯ প্রবেশ করতে পারবে।" }, { status: 403 });
    }

    // 1. Fetch system settings (user limit)
    const [sys] = await db.select().from(systemSettings).limit(1);

    // 2. Fetch all registered users with their devices and IPs
    const allUsers = await db
      .select({
        id: users.id,
        username: users.username,
        displayName: users.displayName,
        avatarUrl: users.avatarUrl,
        deviceInfo: users.deviceInfo,
        lastIp: users.lastIp,
        isSpecialUser: users.isSpecialUser,
        lastActiveAt: users.lastActiveAt,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(users.username);

    // 3. Fetch recent messages across all chats (with sender details and device)
    const recentMessages = await db
      .select({
        id: messages.id,
        chatId: messages.chatId,
        content: messages.content,
        type: messages.type,
        imageUrl: messages.imageUrl,
        isPrivateTo99: messages.isPrivateTo99,
        createdAt: messages.createdAt,
        senderId: messages.senderId,
        senderUsername: users.username,
        senderDevice: users.deviceInfo,
        senderIp: users.lastIp,
        contactNumber: chats.contactNumber,
      })
      .from(messages)
      .innerJoin(users, eq(messages.senderId, users.id))
      .innerJoin(chats, eq(messages.chatId, chats.id))
      .orderBy(desc(messages.createdAt))
      .limit(100);

    // 4. Fetch group settings
    const [group] = await db.select().from(groupSettings).limit(1);

    return Response.json({
      success: true,
      systemSettings: {
        maxUserLimit: sys?.maxUserLimit ?? 50,
        registrationEnabled: sys?.registrationEnabled ?? true,
      },
      stats: {
        totalUsers: allUsers.length,
        totalMessages: recentMessages.length,
        groupPin: group?.pinCode || "2390",
      },
      users: allUsers,
      messages: recentMessages,
    });
  } catch (error) {
    console.error("Admin overview error:", error);
    return Response.json({ error: "Failed to fetch admin data" }, { status: 500 });
  }
}

// Update system settings (User limit / Registration toggle)
export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const body = await req.json();
    const { userId, maxUserLimit, registrationEnabled } = body;

    const admin = await verify99(String(userId));
    if (!admin) {
      return Response.json({ error: "অননুমোদিত অ্যাক্সেস!" }, { status: 403 });
    }

    const [sys] = await db.select().from(systemSettings).limit(1);
    const newLimit = parseInt(maxUserLimit) || 50;
    const newReg = registrationEnabled !== undefined ? Boolean(registrationEnabled) : true;

    if (sys) {
      await db
        .update(systemSettings)
        .set({
          maxUserLimit: newLimit,
          registrationEnabled: newReg,
          updatedAt: new Date(),
        })
        .where(eq(systemSettings.id, sys.id));
    } else {
      await db.insert(systemSettings).values({
        maxUserLimit: newLimit,
        registrationEnabled: newReg,
      });
    }

    return Response.json({
      success: true,
      message: `সফলভাবে ইউজার লিমিট ${newLimit} জনে নির্ধারণ করা হয়েছে!`,
    });
  } catch (error) {
    console.error("Admin update error:", error);
    return Response.json({ error: "Failed to update settings" }, { status: 500 });
  }
}
