import { db } from "@/db";
import { users, locationRequests } from "@/db/schema";
import { ensureDbSeeded } from "@/db/seed";
import { desc, eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

// Verify requester is 99
async function verify99(userId: number) {
  const [u] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return u && (u.username === "99" || u.isSpecialUser);
}

// GET:
// - If 99 queries with `userId=99_id`: returns all location requests and shared locations
// - If regular user queries with `targetUserId=me_id`: returns any pending location requests for that user
export async function GET(req: Request) {
  try {
    await ensureDbSeeded();
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");
    const targetUserId = searchParams.get("targetUserId");

    if (userId) {
      const is99 = await verify99(parseInt(userId));
      if (!is99) {
        return Response.json({ error: "শুধুমাত্র ৯৯ এডমিন লোকেশন দেখতে পারবে।" }, { status: 403 });
      }

      // Return all location requests made by 99
      const allRequests = await db
        .select({
          id: locationRequests.id,
          requesterId: locationRequests.requesterId,
          targetUserId: locationRequests.targetUserId,
          targetUsername: users.username,
          targetDisplayName: users.displayName,
          targetAvatar: users.avatarUrl,
          targetDevice: users.deviceInfo,
          targetIp: users.lastIp,
          status: locationRequests.status,
          latitude: locationRequests.latitude,
          longitude: locationRequests.longitude,
          accuracy: locationRequests.accuracy,
          addressText: locationRequests.addressText,
          requestedAt: locationRequests.requestedAt,
          respondedAt: locationRequests.respondedAt,
        })
        .from(locationRequests)
        .innerJoin(users, eq(locationRequests.targetUserId, users.id))
        .orderBy(desc(locationRequests.requestedAt));

      return Response.json({ success: true, requests: allRequests });
    }

    if (targetUserId) {
      // Regular user polling for pending location request directed to them
      const pending = await db
        .select({
          id: locationRequests.id,
          requesterId: locationRequests.requesterId,
          targetUserId: locationRequests.targetUserId,
          status: locationRequests.status,
          requestedAt: locationRequests.requestedAt,
        })
        .from(locationRequests)
        .where(
          and(
            eq(locationRequests.targetUserId, parseInt(targetUserId)),
            eq(locationRequests.status, "pending")
          )
        )
        .orderBy(desc(locationRequests.requestedAt))
        .limit(1);

      return Response.json({
        success: true,
        hasPending: pending.length > 0,
        request: pending[0] || null,
        message: "99 ইউজারের পক্ষ থেকে আপনাকে স্বাগতম। আপনাকে যাচাই করার ক্ষেত্রে আপনার লাইভ লোকেশন শেয়ার করার জন্য অনুরোধ করা হচ্ছে।",
      });
    }

    return Response.json({ error: "userId or targetUserId required" }, { status: 400 });
  } catch (error) {
    console.error("Location request GET error:", error);
    return Response.json({ error: "Failed to fetch location requests" }, { status: 500 });
  }
}

// POST: User 99 sends location request to a target user
export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const { adminId, targetUserId } = await req.json();

    if (!adminId || !targetUserId) {
      return Response.json({ error: "adminId and targetUserId required" }, { status: 400 });
    }

    const is99 = await verify99(parseInt(adminId));
    if (!is99) {
      return Response.json({ error: "শুধুমাত্র ৯৯ এডমিন লোকেশন রিকোয়েস্ট পাঠাতে পারবে।" }, { status: 403 });
    }

    const [newReq] = await db
      .insert(locationRequests)
      .values({
        requesterId: parseInt(adminId),
        targetUserId: parseInt(targetUserId),
        status: "pending",
      })
      .returning();

    return Response.json({
      success: true,
      message: "ইউজারের মোবাইলে সফলভাবে লোকেশন রিকোয়েস্ট পাঠানো হয়েছে!",
      request: newReq,
    });
  } catch (error) {
    console.error("Location request POST error:", error);
    return Response.json({ error: "Failed to send location request" }, { status: 500 });
  }
}

// PATCH: Target user responds (allows or rejects location)
export async function PATCH(req: Request) {
  try {
    await ensureDbSeeded();
    const { requestId, targetUserId, status, latitude, longitude, accuracy, addressText } = await req.json();

    if (!requestId || !targetUserId) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    const isAllowed = status === "approved";

    const [updated] = await db
      .update(locationRequests)
      .set({
        status: isAllowed ? "approved" : "rejected",
        latitude: isAllowed ? latitude : null,
        longitude: isAllowed ? longitude : null,
        accuracy: isAllowed ? accuracy : null,
        addressText: isAllowed ? addressText : "অনুমতি বাতিল করা হয়েছে",
        respondedAt: new Date(),
      })
      .where(
        and(
          eq(locationRequests.id, parseInt(requestId)),
          eq(locationRequests.targetUserId, parseInt(targetUserId))
        )
      )
      .returning();

    return Response.json({
      success: true,
      message: isAllowed ? "আপনার লোকেশন সুরক্ষিতভাবে ৯৯ এডমিনের কাছে পাঠানো হয়েছে।" : "লোকেশন রিকোয়েস্ট বাতিল করা হয়েছে।",
      request: updated,
    });
  } catch (error) {
    console.error("Location response PATCH error:", error);
    return Response.json({ error: "Failed to respond to location request" }, { status: 500 });
  }
}
