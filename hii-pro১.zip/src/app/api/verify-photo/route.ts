import { validateHumanFace } from "@/lib/faceDetector";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const { imageBase64 } = await req.json();

    if (!imageBase64) {
      return Response.json(
        { isPerson: false, error: "ছবি প্রদান করা হয়নি।" },
        { status: 400 }
      );
    }

    const check = validateHumanFace(imageBase64);

    return Response.json({
      success: true,
      isPerson: check.isPerson,
      confidence: check.confidence,
      reason: check.reason,
    });
  } catch (error) {
    console.error("verify-photo error:", error);
    return Response.json(
      { isPerson: false, error: "ছবি যাচাইকরণ ব্যর্থ হয়েছে।" },
      { status: 500 }
    );
  }
}
