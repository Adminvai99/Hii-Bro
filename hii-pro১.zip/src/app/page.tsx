"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export const dynamic = "force-dynamic";

export default function HomePage() {
  const router = useRouter();

  useEffect(() => {
    let user = null;

    // Check localStorage
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) user = JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }

    // Fallback to cookie
    if (!user) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          user = JSON.parse(decodeURIComponent(match[1]));
        } catch (e) {
          console.error(e);
        }
      }
    }

    if (user && user.id) {
      router.replace(`/chat-list?userId=${user.id}`);
    } else {
      router.replace("/login");
    }
  }, [router]);

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center">
      <div className="w-16 h-16 rounded-full bg-black border-2 border-green-500 shadow-[0_0_30px_rgba(0,255,65,0.6)] flex items-center justify-center mb-4">
        <svg className="w-8 h-8 text-green-400 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
        </svg>
      </div>
      <h1 className="text-2xl font-bold text-green-400">Hii pro</h1>
      <p className="text-green-500/60 text-xs mt-1">Chat • Connect • Earn</p>
    </div>
  );
}
