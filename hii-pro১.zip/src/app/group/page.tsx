"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export const dynamic = "force-dynamic";

interface GroupMsg {
  id: number;
  user: string;
  text: string;
  time: string;
}

export default function GroupPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const userIdParam = searchParams.get("userId");

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [verified, setVerified] = useState(false);
  const [loading, setLoading] = useState(false);

  // Group chat state
  const [groupMessages, setGroupMessages] = useState<GroupMsg[]>([
    { id: 1, user: "99", text: "Welcome to Hii pro Official VIP Group! 🚀", time: "10:00 AM" },
    { id: 2, user: "85", text: "Hello everyone!", time: "10:15 AM" },
  ]);
  const [msgInput, setMsgInput] = useState("");

  // User 99 edit pin
  const [showPinEdit, setShowPinEdit] = useState(false);
  const [newPinValue, setNewPinValue] = useState("");
  const [pinChangeMsg, setPinChangeMsg] = useState("");

  // Load user session
  useEffect(() => {
    let user = null;
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) user = JSON.parse(saved);
    } catch {}

    if (!user) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          user = JSON.parse(decodeURIComponent(match[1]));
        } catch {}
      }
    }

    if (user?.id) {
      setCurrentUser(user);
    } else {
      router.replace("/login");
    }
  }, [router]);

  const is99 = currentUser?.username === "99" || currentUser?.isSpecialUser;

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!pin.trim()) {
      setError("দয়া করে পিন কোড লিখুন");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/group-pin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin: pin.trim() }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "ভুল পিন কোড! সঠিক পিন দিন।");
        setLoading(false);
        return;
      }

      setVerified(true);
      setLoading(false);
    } catch {
      setError("নেটওয়ার্ক সমস্যা");
      setLoading(false);
    }
  };

  const handleSendGroupMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgInput.trim()) return;

    const newMsg: GroupMsg = {
      id: Date.now(),
      user: currentUser?.username || "Me",
      text: msgInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setGroupMessages((prev) => [...prev, newMsg]);
    setMsgInput("");
  };

  const handleChangePinBy99 = async () => {
    if (!newPinValue.trim()) return;
    try {
      const res = await fetch("/api/group-pin", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUser.id,
          newPin: newPinValue.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setPinChangeMsg("পিন সফলভাবে পরিবর্তিত হয়েছে!");
        setNewPinValue("");
        setTimeout(() => setPinChangeMsg(""), 3000);
      } else {
        alert(data.error || "পিন পরিবর্তন করা যায়নি");
      }
    } catch {
      alert("সমস্যা হয়েছে");
    }
  };

  if (!currentUser) {
    return <div className="min-h-screen bg-black" />;
  }

  // If not yet verified with PIN
  if (!verified) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col justify-between relative overflow-hidden select-none">
        {/* Glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-green-500/15 blur-[120px] pointer-events-none" />

        {/* Header - strictly NO phone status bar */}
        <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-green-500/20 px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => router.push(`/chat-list?userId=${currentUser.id}`)}
            className="flex items-center gap-1.5 text-green-400 text-sm font-semibold"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
            <span>Back</span>
          </button>
          <h1 className="text-base font-bold text-green-400">Security Check</h1>
          <div className="w-8" />
        </header>

        {/* PIN Entry Card - STRICTLY NO PIN REVEALED ANYWHERE */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 relative z-10">
          <div className="w-full max-w-sm bg-black/80 border border-green-500/40 rounded-3xl p-7 shadow-[0_0_40px_rgba(0,255,65,0.2)] text-center">
            {/* Lock Icon */}
            <div className="w-16 h-16 rounded-full border-2 border-green-400 bg-green-950/40 flex items-center justify-center mx-auto mb-4 shadow-[0_0_25px_rgba(0,255,65,0.4)]">
              <svg className="w-8 h-8 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>

            <h2 className="text-xl font-bold text-white mb-1">Group Security</h2>
            <p className="text-green-400/80 text-xs mb-6">
              গ্রুপে প্রবেশ করতে গোপন পিন কোড দিন
            </p>

            <form onSubmit={handleVerify} className="space-y-4">
              {/* PIN Input with hidden dots - NO PIN REVEALED */}
              <div>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  value={pin}
                  onChange={(e) => {
                    setPin(e.target.value.replace(/\D/g, ""));
                    setError("");
                  }}
                  placeholder="••••"
                  className="w-full bg-black/60 border border-green-500/50 rounded-2xl py-3 text-center text-2xl font-mono tracking-[0.4em] text-green-300 placeholder-green-800 focus:outline-none focus:border-green-400 focus:shadow-[0_0_20px_rgba(0,255,65,0.4)]"
                  autoFocus
                />
              </div>

              {error && (
                <div className="text-red-400 text-xs bg-red-950/60 border border-red-500/30 rounded-xl py-1.5 px-3">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading || !pin}
                className={`w-full py-3.5 rounded-full font-bold text-black text-sm tracking-wide transition-all ${
                  loading || !pin
                    ? "bg-green-500/30 text-green-800 cursor-not-allowed border border-green-500/20"
                    : "bg-gradient-to-r from-green-400 to-green-500 shadow-[0_0_30px_rgba(0,255,65,0.6)] hover:scale-[1.02] active:scale-[0.98]"
                }`}
              >
                {loading ? "যাচাই করা হচ্ছে..." : "গ্রুপে প্রবেশ করুন"}
              </button>
            </form>

            {/* Quick Admin Access for 99 */}
            {is99 && (
              <div className="mt-5 pt-4 border-t border-green-500/20">
                <button
                  type="button"
                  onClick={() => setVerified(true)}
                  className="text-xs text-yellow-400 hover:underline font-semibold"
                >
                  ⚡ Admin 99 ডিরেক্ট এন্ট্রি
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Nav */}
        <BottomNav active="group" userId={currentUser.id} />
      </div>
    );
  }

  // Verified - Show Group Chat Screen
  return (
    <div className="min-h-screen bg-black text-white flex flex-col relative overflow-hidden select-none">
      <div className="absolute top-0 right-0 w-80 h-80 bg-green-500/10 blur-[100px] pointer-events-none" />

      {/* Header - strictly NO phone status bar */}
      <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-green-500/20 px-3 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => router.push(`/chat-list?userId=${currentUser.id}`)}
            className="p-1.5 rounded-full hover:bg-green-500/20 text-green-400"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="w-10 h-10 rounded-full border border-green-400 bg-green-950/40 flex items-center justify-center text-lg shadow-[0_0_15px_rgba(0,255,65,0.3)]">
            👥
          </div>

          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">Hii pro Group</h2>
            <p className="text-[11px] text-green-400">Verified VIP Members</p>
          </div>
        </div>

        {/* User 99 Edit PIN button */}
        {is99 && (
          <button
            onClick={() => setShowPinEdit(!showPinEdit)}
            className="px-2.5 py-1 rounded-full bg-yellow-500/20 border border-yellow-400 text-yellow-300 text-xs font-bold"
          >
            🔑 Edit PIN
          </button>
        )}
      </header>

      {/* User 99 PIN edit dropdown */}
      {is99 && showPinEdit && (
        <div className="bg-black/95 border-b border-yellow-500/40 p-4 relative z-20">
          <div className="max-w-md mx-auto space-y-2">
            <span className="text-xs text-yellow-300 font-bold block">
              গ্রুপের নতুন পিন কোড সেট করুন (Change Secret PIN):
            </span>
            <div className="flex gap-2">
              <input
                type="text"
                maxLength={6}
                value={newPinValue}
                onChange={(e) => setNewPinValue(e.target.value.replace(/\D/g, ""))}
                placeholder="নতুন পিন কোড"
                className="flex-1 bg-black border border-yellow-500/50 rounded-xl px-3 py-2 text-xs text-yellow-300 font-mono"
              />
              <button
                onClick={handleChangePinBy99}
                className="px-4 py-2 rounded-xl bg-yellow-400 text-black text-xs font-bold hover:bg-yellow-300"
              >
                আপডেট
              </button>
            </div>
            {pinChangeMsg && (
              <p className="text-xs text-green-400">{pinChangeMsg}</p>
            )}
          </div>
        </div>
      )}

      {/* Messages */}
      <main className="flex-1 overflow-y-auto px-4 py-4 space-y-3 pb-24">
        {groupMessages.map((m) => {
          const isMe = m.user === currentUser.username;
          return (
            <div key={m.id} className={`flex flex-col ${isMe ? "items-end" : "items-start"}`}>
              <span className="text-[10px] text-green-500/70 mb-0.5 px-1 font-mono">
                User {m.user} {m.user === "99" ? "👑" : ""}
              </span>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                  isMe
                    ? "bg-green-500 text-black font-medium shadow-[0_0_15px_rgba(0,255,65,0.4)]"
                    : "bg-black/80 border border-green-500/40 text-green-200"
                }`}
              >
                <p>{m.text}</p>
                <span className="block text-[9px] text-right mt-1 opacity-70 font-mono">{m.time}</span>
              </div>
            </div>
          );
        })}
      </main>

      {/* Group input bar (NO calls) */}
      <footer className="fixed bottom-16 left-0 right-0 z-20 bg-black/95 backdrop-blur-xl border-t border-green-500/20 px-3 py-2">
        <form onSubmit={handleSendGroupMsg} className="max-w-md mx-auto flex items-center gap-2">
          <input
            type="text"
            value={msgInput}
            onChange={(e) => setMsgInput(e.target.value)}
            placeholder="Type in group..."
            className="flex-1 bg-black/60 border border-green-500/40 rounded-full px-4 py-2 text-sm text-green-300 placeholder-green-600/70 focus:outline-none focus:border-green-400"
          />
          <button
            type="submit"
            disabled={!msgInput.trim()}
            className="w-9 h-9 rounded-full bg-green-500 text-black flex items-center justify-center disabled:opacity-40"
          >
            <svg className="w-4 h-4 rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19V5m0 0l-7 7m7-7l7 7" />
            </svg>
          </button>
        </form>
      </footer>

      {/* Bottom Nav */}
      <BottomNav active="group" userId={currentUser.id} />
    </div>
  );
}

function BottomNav({ active, userId }: { active: string; userId: number }) {
  const router = useRouter();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-black/90 backdrop-blur-xl border-t border-green-500/30 px-6 py-2.5">
      <div className="max-w-md mx-auto flex items-center justify-around">
        <button
          onClick={() => router.push(`/chat-list?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "chats" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          <span className="text-[11px] font-medium">Chats</span>
        </button>

        <button
          className={`flex flex-col items-center gap-1 ${
            active === "group" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <div className="p-1 rounded-full bg-green-500/20 shadow-[0_0_12px_rgba(0,255,65,0.5)]">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.127-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.127-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <span className="text-[11px] font-semibold">Group</span>
        </button>

        <button
          onClick={() => router.push(`/invite?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "invite" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
          </svg>
          <span className="text-[11px] font-medium">Invite</span>
        </button>

        <button
          onClick={() => router.push(`/more?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "more" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
          <span className="text-[11px] font-medium">More</span>
        </button>
      </div>
    </nav>
  );
}
