"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export const dynamic = "force-dynamic";

export default function InvitePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let user = null;
    try {
      const saved = localStorage.getItem("hii_pro_user");
      if (saved) user = JSON.parse(saved);
    } catch {}

    if (!user) {
      const match = document.cookie.match(/hii_pro_user=([^;]+)/);
      if (match) {
        try {
          user = JSON.parse(decodeURIComponent(match[1]));
        } catch {}
      }
    }

    if (user?.id) {
      setCurrentUser(user);
    } else {
      router.replace("/login");
    }
  }, [router]);

  const inviteUrl = typeof window !== "undefined" ? window.location.origin : "https://hiipro.app";

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`${inviteUrl}/login`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "Hii pro",
        text: "Hii pro তে যোগ দিন — Chat • Connect • Earn! আপনার ২ সংখ্যার নম্বর দিয়ে শুরু করুন।",
        url: inviteUrl,
      });
    } else {
      handleCopyLink();
    }
  };

  if (!currentUser) {
    return <div className="min-h-screen bg-black" />;
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col justify-between relative overflow-hidden select-none">
      <div className="absolute top-0 right-0 w-80 h-80 bg-green-500/10 blur-[100px] pointer-events-none" />

      {/* Header - strictly NO phone status bar */}
      <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-green-500/20 px-4 py-3 flex items-center justify-between">
        <button
          onClick={() => router.push(`/chat-list?userId=${currentUser.id}`)}
          className="flex items-center gap-1.5 text-green-400 text-sm font-semibold"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
          </svg>
          <span>Back</span>
        </button>
        <h1 className="text-base font-bold text-green-400">Invite & Earn</h1>
        <div className="w-8" />
      </header>

      {/* Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 relative z-10 pb-24">
        <div className="w-full max-w-sm bg-black/80 border border-green-500/40 rounded-3xl p-7 text-center shadow-[0_0_35px_rgba(0,255,65,0.2)]">
          <div className="w-20 h-20 rounded-full border-2 border-green-400 bg-green-950/40 flex items-center justify-center mx-auto mb-4 text-3xl shadow-[0_0_30px_rgba(0,255,65,0.5)]">
            🎁
          </div>

          <h2 className="text-xl font-extrabold text-white mb-1">Invite Friends</h2>
          <p className="text-green-400 text-xs font-semibold mb-6">
            Chat • Connect • Earn
          </p>

          <p className="text-xs text-green-300/80 mb-6 leading-relaxed">
            বন্ধুদের Hii pro অ্যাপে আমন্ত্রণ জানান এবং একসাথে চ্যাট ও কানেক্ট করুন। আপনার নিজস্ব ২ অঙ্কের নম্বর শেয়ার করুন।
          </p>

          {/* User's 2-digit number badge */}
          <div className="bg-green-950/40 border border-green-500/40 rounded-2xl p-4 mb-6">
            <span className="text-[10px] text-green-500/70 block uppercase">আপনার অ্যাকাউন্ট নম্বর:</span>
            <span className="text-3xl font-extrabold font-mono text-green-300 tracking-wider">
              {currentUser.username}
            </span>
          </div>

          {/* Action buttons */}
          <div className="space-y-3">
            <button
              onClick={handleShare}
              className="w-full py-3.5 rounded-full bg-gradient-to-r from-green-400 to-green-500 text-black font-bold text-sm shadow-[0_0_25px_rgba(0,255,65,0.6)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
              <span>শেয়ার করুন (Share Invite)</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="w-full py-3 rounded-full border border-green-500/40 text-green-300 text-xs font-semibold hover:bg-green-500/10 transition-all"
            >
              {copied ? "✓ লিংক কপি করা হয়েছে!" : "লিংক কপি করুন (Copy Link)"}
            </button>
          </div>
        </div>
      </main>

      {/* Bottom Nav */}
      <BottomNav active="invite" userId={currentUser.id} />
    </div>
  );
}

function BottomNav({ active, userId }: { active: string; userId: number }) {
  const router = useRouter();
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-black/90 backdrop-blur-xl border-t border-green-500/30 px-6 py-2.5">
      <div className="max-w-md mx-auto flex items-center justify-around">
        <button
          onClick={() => router.push(`/chat-list?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "chats" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          <span className="text-[11px] font-medium">Chats</span>
        </button>

        <button
          onClick={() => router.push(`/group?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "group" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.127-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.127-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <span className="text-[11px] font-medium">Group</span>
        </button>

        <button
          className={`flex flex-col items-center gap-1 ${
            active === "invite" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <div className="p-1 rounded-full bg-green-500/20 shadow-[0_0_12px_rgba(0,255,65,0.5)]">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
            </svg>
          </div>
          <span className="text-[11px] font-semibold">Invite</span>
        </button>

        <button
          onClick={() => router.push(`/more?userId=${userId}`)}
          className={`flex flex-col items-center gap-1 ${
            active === "more" ? "text-green-400" : "text-green-500/60 hover:text-green-400"
          }`}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
          <span className="text-[11px] font-medium">More</span>
        </button>
      </div>
    </nav>
  );
}
