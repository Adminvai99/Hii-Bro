"use client";

import { useEffect, useState, useRef, useCallback } from "react";

export function LocationRequestModal({ currentUserId }: { currentUserId: number }) {
  const [pendingReq, setPendingReq] = useState<any>(null);
  const [showPopup, setShowPopup] = useState(false);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");

  // Poll for pending location request directed to current user
  const checkPendingRequests = useCallback(async () => {
    if (!currentUserId) return;
    try {
      const res = await fetch(`/api/location-request?targetUserId=${currentUserId}`);
      const data = await res.json();
      if (data.hasPending && data.request) {
        setPendingReq(data.request);
        setShowPopup(true);
      }
    } catch {}
  }, [currentUserId]);

  useEffect(() => {
    checkPendingRequests();
    const interval = setInterval(checkPendingRequests, 5000);
    return () => clearInterval(interval);
  }, [checkPendingRequests]);

  const handleAllowLocation = () => {
    if (!navigator.geolocation) {
      alert("আপনার ব্রাউজারে লোকেশন সার্ভিস সাপোর্ট করছে না।");
      return;
    }

    setLoading(true);
    setStatusMessage("আপনার লাইভ লোকেশন সংগ্রহ করা হচ্ছে...");

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const lat = pos.coords.latitude;
          const lon = pos.coords.longitude;
          const acc = pos.coords.accuracy;

          const res = await fetch("/api/location-request", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              requestId: pendingReq.id,
              targetUserId: currentUserId,
              status: "approved",
              latitude: lat,
              longitude: lon,
              accuracy: acc,
              addressText: `Lat: ${lat.toFixed(5)}, Lon: ${lon.toFixed(5)} (±${Math.round(acc)}m)`,
            }),
          });

          const data = await res.json();
          setLoading(false);
          setShowPopup(false);
          alert(data.message || "লোকেশন শেয়ারিং সফল হয়েছে।");
        } catch {
          setLoading(false);
          alert("লোকেশন পাঠাতে সমস্যা হয়েছে।");
        }
      },
      async (err) => {
        setLoading(false);
        console.warn("Geolocation permission error:", err);
        // Fallback or prompt
        const manual = window.confirm(
          "জিপিএস লোকেশন নেওয়া যায়নি। আপনি কি আনুমানিক লোকেশন শেয়ার করতে চান?"
        );
        if (manual) {
          await fetch("/api/location-request", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              requestId: pendingReq.id,
              targetUserId: currentUserId,
              status: "approved",
              latitude: 23.8103, // Default Dhaka coordinates fallback
              longitude: 90.4125,
              accuracy: 100,
              addressText: "User Browser Location Allowed",
            }),
          });
        }
        setShowPopup(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const handleRejectLocation = async () => {
    if (!pendingReq) return;
    try {
      await fetch("/api/location-request", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requestId: pendingReq.id,
          targetUserId: currentUserId,
          status: "rejected",
        }),
      });
    } catch {}
    setShowPopup(false);
  };

  if (!showPopup || !pendingReq) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div className="w-full max-w-sm bg-black border-2 border-green-400 rounded-3xl p-6 shadow-[0_0_50px_rgba(0,255,65,0.4)] text-center relative overflow-hidden">
        {/* Glow behind modal */}
        <div className="absolute -top-12 -left-12 w-32 h-32 bg-green-500/30 blur-[40px] pointer-events-none rounded-full" />

        {/* Crown & GPS Pin Icon */}
        <div className="w-16 h-16 rounded-full border-2 border-green-400 bg-green-950/60 flex items-center justify-center mx-auto mb-4 text-2xl shadow-[0_0_25px_rgba(0,255,65,0.6)]">
          📍
        </div>

        <h3 className="text-base font-extrabold text-white mb-1">
          লাইভ লোকেশন রিকোয়েস্ট
        </h3>
        <p className="text-[10px] text-yellow-300 font-bold uppercase tracking-wider mb-4">
          Admin 99 Verification
        </p>

        {/* Exact message requirement */}
        <div className="bg-green-950/30 border border-green-500/30 rounded-2xl p-4 text-xs text-green-200 leading-relaxed mb-5 text-left space-y-2">
          <p className="font-semibold text-green-300">
            "99 ইউজারের পক্ষ থেকে আপনাকে স্বাগতম!
          </p>
          <p>
            আপনাকে যাচাই করার ক্ষেত্রে আপনার লাইভ লোকেশন শেয়ার করার জন্য অনুরোধ করা হচ্ছে।"
          </p>
          <p className="text-[10px] text-green-500/80 italic">
            * এটি শুধুমাত্র ৯৯ এডমিন দেখতে পারবে, অন্য কোনো ইউজার দেখতে পারবে না।
          </p>
        </div>

        {statusMessage && (
          <p className="text-xs text-green-400 mb-3 animate-pulse">{statusMessage}</p>
        )}

        {/* Action Buttons: Allow / Reject */}
        <div className="space-y-2">
          <button
            onClick={handleAllowLocation}
            disabled={loading}
            className="w-full py-3 rounded-full bg-gradient-to-r from-green-400 to-green-500 text-black font-extrabold text-xs shadow-[0_0_25px_rgba(0,255,65,0.7)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            {loading ? (
              <span>যাচাই হচ্ছে...</span>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
                <span>Allow (লোকেশন শেয়ার করুন)</span>
              </>
            )}
          </button>

          <button
            onClick={handleRejectLocation}
            disabled={loading}
            className="w-full py-2.5 rounded-full border border-red-500/40 text-red-400 text-xs font-semibold hover:bg-red-950/30 transition-all"
          >
            Don't Allow (বাতিল)
          </button>
        </div>
      </div>
    </div>
  );
}
