/**
 * Simple helper to parse User-Agent string into human-friendly device & mobile model info
 */
export function parseDeviceFromUserAgent(ua: string | null | undefined): string {
  if (!ua) return "অজানা ডিভাইস";

  const lower = ua.toLowerCase();

  // Common Phone Brands & Models
  if (lower.includes("iphone")) {
    const match = ua.match(/iPhone(?:\sOS\s([\d_]+))?/);
    return match ? `Apple iPhone (iOS ${match[1] ? match[1].replace(/_/g, ".") : ""})` : "Apple iPhone";
  }

  if (lower.includes("ipad")) {
    return "Apple iPad";
  }

  // Android models
  if (lower.includes("android")) {
    // Often contains "; Model Build/" or "; Model)"
    const androidMatch = ua.match(/Android\s*[\d.]+;\s*([^;)]+)/i);
    let model = androidMatch && androidMatch[1] ? androidMatch[1].trim() : "Android Mobile";

    // Clean build IDs
    model = model.replace(/\s*Build\/.*$/i, "").trim();

    // Identify brand if present
    if (/samsung|sm-[a-z0-9]+/i.test(ua)) return `Samsung (${model})`;
    if (/xiaomi|redmi|poco/i.test(ua)) return `Xiaomi/Redmi (${model})`;
    if (/realme/i.test(ua)) return `Realme (${model})`;
    if (/vivo/i.test(ua)) return `Vivo (${model})`;
    if (/oppo|cph/i.test(ua)) return `Oppo (${model})`;
    if (/infinix/i.test(ua)) return `Infinix (${model})`;
    if (/tecno/i.test(ua)) return `Tecno (${model})`;
    if (/oneplus/i.test(ua)) return `OnePlus (${model})`;
    if (/pixel/i.test(ua)) return `Google Pixel (${model})`;
    if (/huawei|honor/i.test(ua)) return `Huawei (${model})`;
    if (/motorola|moto/i.test(ua)) return `Motorola (${model})`;

    return `Android (${model})`;
  }

  if (lower.includes("windows")) return "Windows PC / Laptop";
  if (lower.includes("macintosh") || lower.includes("mac os")) return "Apple Mac / MacBook";
  if (lower.includes("linux")) return "Linux Device";

  return "Mobile Device";
}
